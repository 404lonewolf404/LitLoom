# Security Notes

The application binds to `127.0.0.1` by default and is designed for a single local research workspace. API keys are accepted through the OpenAI-compatible settings panel or environment variables and are deliberately kept out of SQLite, audit events, request bodies in logs, and backup manifests.

The model configuration accepts `https` for remote providers and `http` only for loopback services. Before enabling an external provider, review its retention policy. The current AI workflow sends only the explicitly consented paper title, authors, year, venue, and abstract; local notes and PDF attachments are not uploaded.

Backups contain paper metadata, notes, audit history, and local PDF attachments. Treat backup ZIP files as sensitive research material. Store them in a protected directory and do not commit `data/` or backup archives to source control.

Future encrypted backup and system credential-store support must preserve the same constraints: secrets must not enter logs, exports, or model prompts without an explicit user action.
