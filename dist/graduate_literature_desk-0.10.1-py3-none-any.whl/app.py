from __future__ import annotations

import hashlib
import ipaddress
import json
import mimetypes
import os
import re
import sqlite3
import sys
import threading
import time
import uuid
import xml.etree.ElementTree as ET
import zipfile
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from email.parser import BytesParser
from email.policy import default
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, quote, urlencode, urlparse
from urllib.request import Request, urlopen

from literature_desk import __version__
from literature_desk.domain import PAPER_STATUSES, QUERY_DECISIONS, RECOMMENDATION_DECISIONS, SOURCE_NAMES


ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
if not STATIC.is_dir():
    # Wheel installs place data-files under the interpreter prefix while
    # editable/source installs keep them beside app.py.
    STATIC = Path(sys.prefix) / "static"
DATA_DIR = Path(os.environ.get("LITERATURE_DATA_DIR", ROOT / "data")).expanduser().resolve()
FILES_DIR = DATA_DIR / "files"
BACKUP_DIR = DATA_DIR / "backups"
DB_PATH = DATA_DIR / "literature.sqlite3"
HOST = os.environ.get("LITERATURE_HOST", "127.0.0.1")
PORT = int(os.environ.get("LITERATURE_PORT", "8765"))
if not ipaddress.ip_address(HOST).is_loopback:
    raise RuntimeError("研究生论文工作台仅允许绑定本机回环地址；请将 LITERATURE_HOST 设为 127.0.0.1")
APP_VERSION = __version__
DB_SCHEMA_VERSION = 7
USER_AGENT = f"GraduateLiteratureDesk/{APP_VERSION} (local research tool; mailto:local@example.invalid)"
DB_LOCK = threading.RLock()
STOP_EVENT = threading.Event()
RUNTIME_MODEL_KEY = ""
PROCESS_STARTED_AT = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
SCHEDULER_STARTED_AT = ""
SCHEDULER_LAST_TICK = ""
RUNTIME_METRICS_LOCK = threading.Lock()
RUNTIME_METRICS = {
    "window_started_at": PROCESS_STARTED_AT,
    "requests_total": 0,
    "errors_4xx": 0,
    "errors_5xx": 0,
    "last_request_at": "",
    "durations_ms": [],
    "routes": {},
}


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _percentile(values: list[float], percentile: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    rank = max(0, min(len(ordered) - 1, round((percentile / 100) * (len(ordered) - 1))))
    return round(float(ordered[rank]), 2)


def record_runtime_request(method: str, path: str, status: int, duration_ms: float) -> None:
    """Record bounded process metrics for local SLOs without persisting payloads."""
    route = clean_text(path.split("?", 1)[0], 180)
    key = f"{clean_text(method, 12).upper()} {route}"
    with RUNTIME_METRICS_LOCK:
        RUNTIME_METRICS["requests_total"] += 1
        RUNTIME_METRICS["errors_4xx"] += int(400 <= status < 500)
        RUNTIME_METRICS["errors_5xx"] += int(status >= 500)
        RUNTIME_METRICS["last_request_at"] = now_iso()
        durations = RUNTIME_METRICS["durations_ms"]
        durations.append(round(max(0.0, float(duration_ms)), 2))
        if len(durations) > 500:
            del durations[:-500]
        route_metrics = RUNTIME_METRICS["routes"].setdefault(key, {"requests": 0, "errors": 0, "last_status": status})
        route_metrics["requests"] += 1
        route_metrics["errors"] += int(status >= 400)
        route_metrics["last_status"] = status


def runtime_metrics_summary() -> dict:
    """Return an operator-safe snapshot of the current process performance window."""
    with RUNTIME_METRICS_LOCK:
        snapshot = {
            "window_started_at": RUNTIME_METRICS["window_started_at"],
            "requests_total": RUNTIME_METRICS["requests_total"],
            "errors_4xx": RUNTIME_METRICS["errors_4xx"],
            "errors_5xx": RUNTIME_METRICS["errors_5xx"],
            "last_request_at": RUNTIME_METRICS["last_request_at"],
            "durations_ms": list(RUNTIME_METRICS["durations_ms"]),
            "routes": {key: dict(value) for key, value in RUNTIME_METRICS["routes"].items()},
        }
    durations = snapshot.pop("durations_ms")
    total = snapshot["requests_total"]
    snapshot.update({
        "sample_size": len(durations),
        "p50_ms": _percentile(durations, 50),
        "p95_ms": _percentile(durations, 95),
        "error_rate_pct": round(((snapshot["errors_4xx"] + snapshot["errors_5xx"]) / total) * 100, 2) if total else 0,
        "server_error_rate_pct": round((snapshot["errors_5xx"] / total) * 100, 2) if total else 0,
        "route_count": len(snapshot["routes"]),
        "top_routes": sorted(
            ({"route": key, **value} for key, value in snapshot["routes"].items()),
            key=lambda item: (-item["requests"], item["route"]),
        )[:20],
    })
    try:
        started = datetime.fromisoformat(snapshot["window_started_at"])
        snapshot["uptime_seconds"] = max(0, round((datetime.now(timezone.utc) - started).total_seconds()))
    except (TypeError, ValueError):
        snapshot["uptime_seconds"] = 0
    return snapshot


def model_settings() -> dict:
    """Return OpenAI-compatible settings without ever returning the secret."""
    with DB_LOCK, db_session() as db:
        row = db.execute("SELECT * FROM model_config WHERE id=1").fetchone()
    env_key = os.environ.get("LIT_AGENT_API_KEY", "")
    has_saved = bool(row and row["updated_at"])
    base_url = (row["base_url"] if has_saved and row["base_url"] else os.environ.get("LIT_AGENT_BASE_URL", "https://api.openai.com/v1")).rstrip("/")
    model = row["model"] if has_saved and row["model"] else os.environ.get("LIT_AGENT_MODEL", "gpt-4.1-mini")
    temperature = float(row["temperature"] if row else 0.2)
    key = RUNTIME_MODEL_KEY or env_key
    enabled = bool(row["enabled"]) if has_saved else bool(env_key)
    return {"provider": "openai", "base_url": base_url, "model": model, "temperature": temperature, "enabled": enabled, "api_key_set": bool(key), "updated_at": row["updated_at"] if row else ""}


def save_model_settings(data: dict) -> dict:
    global RUNTIME_MODEL_KEY
    provider = str(data.get("provider", "openai")).strip().lower()
    if provider != "openai":
        raise ValueError("当前配置中心使用 OpenAI Chat Completions 兼容格式")
    base_url = str(data.get("base_url", "https://api.openai.com/v1")).strip().rstrip("/")
    parsed = urlparse(base_url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError("Base URL 必须是完整的 http(s) 地址")
    if parsed.scheme == "http" and parsed.hostname not in {"127.0.0.1", "localhost", "::1"}:
        raise ValueError("非本机服务请使用 HTTPS")
    model = clean_text(data.get("model", "gpt-4.1-mini"), 200) or "gpt-4.1-mini"
    try:
        temperature = min(2.0, max(0.0, float(data.get("temperature", 0.2))))
    except (TypeError, ValueError):
        raise ValueError("temperature 必须是 0 到 2 之间的数字")
    if "api_key" in data:
        supplied = str(data.get("api_key") or "").strip()
        if supplied:
            RUNTIME_MODEL_KEY = supplied
        elif data.get("clear_api_key"):
            RUNTIME_MODEL_KEY = ""
    enabled = int(bool(data.get("enabled", True)))
    with DB_LOCK, db_session() as db:
        db.execute("UPDATE model_config SET provider=?,base_url=?,model=?,temperature=?,enabled=?,updated_at=? WHERE id=1", (provider, base_url, model, temperature, enabled, now_iso()))
        record_audit(db, "model.settings.updated", "model_config", "1", {"provider": provider, "base_url": base_url, "model": model, "enabled": bool(enabled)})
    return model_settings()


def test_model_connection() -> dict:
    settings = model_settings()
    if not settings["api_key_set"]:
        raise ValueError("尚未配置 API Key")
    req = Request(settings["base_url"] + "/models", headers={"Authorization": "Bearer " + (RUNTIME_MODEL_KEY or os.environ.get("LIT_AGENT_API_KEY", "")), "Accept": "application/json", "User-Agent": USER_AGENT})
    with urlopen(req, timeout=20) as response:
        if response.status < 200 or response.status >= 300:
            raise ValueError(f"模型服务返回 HTTP {response.status}")
    return {"ok": True, "base_url": settings["base_url"], "model": settings["model"], "checked_at": now_iso()}


def agent_discovery_plan(query: str, sources: list[str], options: dict | None = None) -> dict:
    """Optionally add model-proposed terminology to the deterministic plan.

    Only the user's query and extracted facets are sent.  The model cannot
    write to the library; its output is treated as candidate search wording
    and is bounded, parsed and shown as a separate lane.
    """
    raw = clean_text(query, 1000)
    if not raw:
        raise ValueError("需要检索词")
    active_sources = [source for source in sources if source in SOURCE_NAMES and source in SOURCE_SEARCH]
    plan = search_query_plan(raw, active_sources, options or {})
    settings = model_settings()
    api_key = RUNTIME_MODEL_KEY or os.environ.get("LIT_AGENT_API_KEY", "")
    if not api_key or not settings["enabled"]:
        plan["ai_expansion"] = {"enabled": False, "reason": "未启用模型，已使用本地规则检索计划"}
        return plan
    prompt = "你是学术检索规划器。只根据用户的研究问题和已识别维度，提出可用于学术数据库检索的英文同义词、缩写、相邻术语和最多4条短检索表达。不要编造论文、作者、DOI或事实。输出严格 JSON：{synonyms:[string], adjacent_terms:[string], queries:[string]}。"
    user = json.dumps({"query": raw, "facets": plan.get("facets", {}), "existing_terms": plan.get("expanded_concept_terms", [])[:24]}, ensure_ascii=False)
    body = json.dumps({"model": settings["model"], "messages": [{"role": "system", "content": prompt}, {"role": "user", "content": user}], "temperature": min(0.4, settings["temperature"])}, ensure_ascii=False).encode("utf-8")
    req = Request(settings["base_url"] + "/chat/completions", data=body, headers={"Authorization": "Bearer " + api_key, "Content-Type": "application/json", "User-Agent": USER_AGENT}, method="POST")
    with urlopen(req, timeout=45) as response:
        result = json.loads(response.read().decode("utf-8", "replace"))
    content = result.get("choices", [{}])[0].get("message", {}).get("content", "")
    content = re.sub(r"^```(?:json)?\s*|\s*```$", "", str(content).strip(), flags=re.I)
    try:
        proposal = json.loads(content)
    except (TypeError, ValueError) as exc:
        raise ValueError("模型检索规划输出不是有效 JSON") from exc
    if not isinstance(proposal, dict):
        raise ValueError("模型检索规划格式无效")
    existing = {item.get("query", "").casefold() for item in plan.get("query_variants", [])}
    added = []
    for kind, values in (("AI同义词", proposal.get("synonyms", [])), ("AI相邻术语", proposal.get("adjacent_terms", [])), ("AI检索表达", proposal.get("queries", []))):
        if not isinstance(values, list):
            continue
        for value in values:
            candidate = clean_text(value, 240)
            if not candidate or candidate.casefold() in existing or len(added) >= 8:
                continue
            existing.add(candidate.casefold())
            lane = "ai-adjacent" if kind == "AI相邻术语" else "ai"
            added.append({"id": f"ai-{len(added) + 1}", "query": candidate, "kind": kind, "reason": "模型根据当前研究问题提出，需人工确认后用于召回", "lane": lane})
    plan["query_variants"] = [*plan.get("query_variants", []), *added]
    plan["expansion_count"] = max(0, len(plan["query_variants"]) - 1)
    if added:
        plan["coverage_layers"] = [*plan.get("coverage_layers", []), "模型语义扩展（待确认）"]
    plan["ai_expansion"] = {"enabled": True, "model": settings["model"], "added": len(added), "requires_review": True}
    return plan


def connect() -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB_PATH, timeout=30)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    db.execute("PRAGMA journal_mode=WAL")
    return db


@contextmanager
def db_session():
    db = connect()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def record_audit(db: sqlite3.Connection, event_type: str, entity_type: str = "", entity_id: str = "", payload: dict | None = None) -> None:
    """Persist a small, secret-free event for debugging and product metrics."""
    safe_payload = payload or {}
    db.execute(
        "INSERT INTO audit_events(event_type,entity_type,entity_id,payload_json,created_at) VALUES(?,?,?,?,?)",
        (clean_text(event_type, 120), clean_text(entity_type, 120), clean_text(entity_id, 200), json.dumps(safe_payload, ensure_ascii=False)[:12000], now_iso()),
    )


def init_db() -> None:
    with DB_LOCK, db_session() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS papers (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            title_key TEXT NOT NULL,
            authors TEXT NOT NULL DEFAULT '',
            year INTEGER,
            abstract TEXT NOT NULL DEFAULT '',
            doi TEXT NOT NULL DEFAULT '',
            arxiv_id TEXT NOT NULL DEFAULT '',
            venue TEXT NOT NULL DEFAULT '',
            url TEXT NOT NULL DEFAULT '',
            pdf_url TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'inbox',
            topic TEXT NOT NULL DEFAULT '',
            tags_json TEXT NOT NULL DEFAULT '[]',
            notes TEXT NOT NULL DEFAULT '',
            is_favorite INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS paper_title_key_idx ON papers(title_key);
        CREATE INDEX IF NOT EXISTS paper_status_idx ON papers(status);
        CREATE INDEX IF NOT EXISTS paper_year_idx ON papers(year);
        CREATE TABLE IF NOT EXISTS source_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            paper_id TEXT NOT NULL REFERENCES papers(id) ON DELETE CASCADE,
            source TEXT NOT NULL,
            external_id TEXT NOT NULL DEFAULT '',
            query_id TEXT NOT NULL DEFAULT '',
            fetched_at TEXT NOT NULL,
            raw_json TEXT NOT NULL DEFAULT '{}',
            UNIQUE(paper_id, source, external_id, query_id)
        );
        CREATE TABLE IF NOT EXISTS saved_queries (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            query TEXT NOT NULL,
            sources_json TEXT NOT NULL DEFAULT '["arxiv"]',
            search_options_json TEXT NOT NULL DEFAULT '{}',
            cadence_hours INTEGER NOT NULL DEFAULT 168,
            active INTEGER NOT NULL DEFAULT 1,
            last_run_at TEXT NOT NULL DEFAULT '',
            next_run_at TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS runs (
            id TEXT PRIMARY KEY,
            query_id TEXT NOT NULL DEFAULT '',
            query_name TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL,
            started_at TEXT NOT NULL,
            completed_at TEXT NOT NULL DEFAULT '',
            new_count INTEGER NOT NULL DEFAULT 0,
            duplicate_count INTEGER NOT NULL DEFAULT 0,
            sources_json TEXT NOT NULL DEFAULT '[]',
            source_details_json TEXT NOT NULL DEFAULT '[]',
            error TEXT NOT NULL DEFAULT '',
            is_scheduled INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS query_matches (
            query_id TEXT NOT NULL,
            paper_id TEXT NOT NULL REFERENCES papers(id) ON DELETE CASCADE,
            first_seen_at TEXT NOT NULL,
            last_seen_at TEXT NOT NULL,
            seen_count INTEGER NOT NULL DEFAULT 1,
            first_run_id TEXT NOT NULL DEFAULT '',
            last_run_id TEXT NOT NULL DEFAULT '',
            score INTEGER NOT NULL DEFAULT 0,
            tier TEXT NOT NULL DEFAULT '低相关',
            explanation_json TEXT NOT NULL DEFAULT '[]',
            score_version TEXT NOT NULL DEFAULT 'triage-v1',
            user_decision TEXT NOT NULL DEFAULT 'new',
            viewed_at TEXT NOT NULL DEFAULT '',
            PRIMARY KEY(query_id, paper_id)
        );
        CREATE INDEX IF NOT EXISTS query_matches_last_seen_idx ON query_matches(query_id,last_seen_at);
        CREATE TABLE IF NOT EXISTS citation_edges (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_paper_id TEXT NOT NULL REFERENCES papers(id) ON DELETE CASCADE,
            target_external_id TEXT NOT NULL,
            provider TEXT NOT NULL,
            discovered_at TEXT NOT NULL,
            last_seen_at TEXT NOT NULL,
            raw_json TEXT NOT NULL DEFAULT '{}',
            UNIQUE(source_paper_id,target_external_id,provider)
        );
        CREATE INDEX IF NOT EXISTS citation_edges_source_idx ON citation_edges(source_paper_id);
        CREATE TABLE IF NOT EXISTS attachments (
            id TEXT PRIMARY KEY,
            paper_id TEXT NOT NULL REFERENCES papers(id) ON DELETE CASCADE,
            original_name TEXT NOT NULL,
            stored_name TEXT NOT NULL UNIQUE,
            sha256 TEXT NOT NULL,
            byte_size INTEGER NOT NULL,
            added_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS ai_artifacts (
            id TEXT PRIMARY KEY,
            paper_id TEXT NOT NULL REFERENCES papers(id) ON DELETE CASCADE,
            artifact_type TEXT NOT NULL,
            provider TEXT NOT NULL,
            model TEXT NOT NULL,
            prompt_version TEXT NOT NULL,
            input_sha256 TEXT NOT NULL,
            answer TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS learning_feedback (
            paper_id TEXT NOT NULL REFERENCES papers(id) ON DELETE CASCADE,
            scope TEXT NOT NULL DEFAULT 'global',
            decision TEXT NOT NULL,
            note TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL,
            PRIMARY KEY(paper_id, scope)
        );
        CREATE INDEX IF NOT EXISTS learning_feedback_decision_idx ON learning_feedback(decision);
        CREATE TABLE IF NOT EXISTS document_pages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            attachment_id TEXT NOT NULL REFERENCES attachments(id) ON DELETE CASCADE,
            paper_id TEXT NOT NULL REFERENCES papers(id) ON DELETE CASCADE,
            page_number INTEGER NOT NULL,
            text TEXT NOT NULL DEFAULT '',
            char_count INTEGER NOT NULL DEFAULT 0,
            quality TEXT NOT NULL DEFAULT 'empty',
            extractor TEXT NOT NULL DEFAULT '',
            text_sha256 TEXT NOT NULL DEFAULT '',
            extracted_at TEXT NOT NULL,
            UNIQUE(attachment_id, page_number)
        );
        CREATE INDEX IF NOT EXISTS document_pages_paper_idx ON document_pages(paper_id,page_number);
        CREATE INDEX IF NOT EXISTS document_pages_search_idx ON document_pages(paper_id,quality);
        CREATE TABLE IF NOT EXISTS audit_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL,
            entity_type TEXT NOT NULL DEFAULT '',
            entity_id TEXT NOT NULL DEFAULT '',
            payload_json TEXT NOT NULL DEFAULT '{}',
            created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS audit_events_created_idx ON audit_events(created_at);
        CREATE INDEX IF NOT EXISTS audit_events_type_idx ON audit_events(event_type);
        CREATE TABLE IF NOT EXISTS model_config (
            id INTEGER PRIMARY KEY CHECK(id=1),
            provider TEXT NOT NULL DEFAULT 'openai',
            base_url TEXT NOT NULL DEFAULT 'https://api.openai.com/v1',
            model TEXT NOT NULL DEFAULT 'gpt-4.1-mini',
            temperature REAL NOT NULL DEFAULT 0.2,
            enabled INTEGER NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL
        );
        INSERT OR IGNORE INTO model_config(id,provider,base_url,model,temperature,enabled,updated_at)
            VALUES(1,'openai','https://api.openai.com/v1','gpt-4.1-mini',0.2,0,'');
        CREATE TABLE IF NOT EXISTS app_meta (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        """)
        db.execute("INSERT OR IGNORE INTO app_meta(key,value) VALUES (?,?)", ("schema_version", str(DB_SCHEMA_VERSION)))
        schema_row = db.execute("SELECT value FROM app_meta WHERE key='schema_version'").fetchone()
        try:
            current_schema = int(schema_row[0]) if schema_row else 0
        except (TypeError, ValueError):
            current_schema = 0
        if current_schema < DB_SCHEMA_VERSION:
            db.execute("UPDATE app_meta SET value=? WHERE key='schema_version'", (str(DB_SCHEMA_VERSION),))
        # Older schema 5 databases were created before saved query filters
        # became persistent.  SQLite has no IF NOT EXISTS for ALTER TABLE.
        query_columns = {row[1] for row in db.execute("PRAGMA table_info(saved_queries)").fetchall()}
        if "search_options_json" not in query_columns:
            db.execute("ALTER TABLE saved_queries ADD COLUMN search_options_json TEXT NOT NULL DEFAULT '{}'")
        run_columns = {row[1] for row in db.execute("PRAGMA table_info(runs)").fetchall()}
        if "source_details_json" not in run_columns:
            db.execute("ALTER TABLE runs ADD COLUMN source_details_json TEXT NOT NULL DEFAULT '[]'")


def norm_doi(value: str) -> str:
    value = (value or "").strip().lower()
    value = re.sub(r"^(https?://(dx\.)?doi\.org/|doi:\s*)", "", value)
    return value.strip().rstrip(".,; ")


def norm_arxiv(value: str) -> str:
    value = (value or "").strip().lower()
    value = re.sub(r"^(https?://)?(www\.)?arxiv\.org/(abs|pdf)/", "", value)
    value = re.sub(r"\.pdf$", "", value)
    value = re.sub(r"v\d+$", "", value)
    return value.strip()


def title_key(value: str) -> str:
    value = (value or "").lower()
    value = re.sub(r"[^\w\s]", " ", value, flags=re.UNICODE)
    return " ".join(value.split())


# The first relevance layer is deliberately local and explainable. It is a
# triage signal, not a claim that two papers are semantically equivalent.
REL_STOPWORDS = {
    "and", "or", "the", "for", "with", "from", "using", "based", "via", "into", "that",
    "this", "these", "those", "model", "models", "method", "methods", "paper", "study",
    "approach", "towards", "learning", "large", "language", "system", "systems", "data",
    "的", "和", "与", "及", "基于", "用于", "研究", "方法", "模型", "学习", "数据",
}

# These are conservative, high-signal research vocabulary bridges.  They are
# used to issue a small number of additional connector queries, never to
# rewrite the user's original query.  Keeping the map local makes the plan
# inspectable and means the feature remains useful without an AI key.
SEARCH_CONCEPT_ALIASES = {
    "多模态推理": ("multimodal reasoning", "multimodal inference"),
    "多模态": ("multimodal", "multi-modal", "vision-language"),
    "推理": ("reasoning", "inference"),
    "视觉问答": ("visual question answering", "vqa"),
    "视频理解": ("video understanding", "video comprehension"),
    "检索增强生成": ("retrieval augmented generation", "rag"),
    "检索增强": ("retrieval augmented", "retrieval-augmented"),
    "大语言模型": ("large language model", "llm"),
    "视觉语言模型": ("vision-language model", "vlm"),
    "计算机视觉": ("computer vision", "visual recognition"),
    "自然语言处理": ("natural language processing", "nlp"),
    "知识图谱": ("knowledge graph", "knowledge graphs"),
    "图神经网络": ("graph neural network", "gnn"),
    "强化学习": ("reinforcement learning", "rl"),
    "小样本": ("few-shot", "few shot"),
    "零样本": ("zero-shot", "zero shot"),
    "学术检索": ("scholarly search", "academic retrieval"),
    "multimodal": ("multi-modal", "vision-language", "cross-modal"),
    "multi-modal": ("multimodal", "vision-language", "cross-modal"),
    "vision language": ("vision-language", "multimodal"),
    "vision-language": ("vision language", "multimodal"),
    "large language model": ("llm", "foundation model"),
    "large language models": ("llm", "foundation models"),
    "llm": ("large language model", "foundation model"),
    "retrieval augmented generation": ("retrieval-augmented generation", "rag"),
    "retrieval-augmented generation": ("retrieval augmented generation", "rag"),
    "rag": ("retrieval augmented generation", "retrieval-augmented generation"),
    "reinforcement learning": ("rl", "reinforcement-learning"),
    "computer vision": ("visual recognition", "image understanding"),
    "natural language processing": ("nlp", "language understanding"),
    "graph neural network": ("gnn", "graph convolutional network"),
    "generative adversarial network": ("gan", "adversarial generation"),
    "parameter efficient fine tuning": ("parameter-efficient fine-tuning", "peft"),
    "parameter-efficient fine-tuning": ("parameter efficient fine tuning", "peft"),
    "few shot": ("few-shot", "low-resource"),
    "zero shot": ("zero-shot", "open-vocabulary"),
    "智能体": ("agent", "autonomous agent", "ai agent"),
    "人工智能体": ("ai agent", "intelligent agent"),
    "多智能体": ("multi-agent", "multi agent"),
    "长视频": ("long video", "long-form video", "long video understanding"),
    "视频生成": ("video generation", "text-to-video", "generative video"),
    "图像生成": ("image generation", "text-to-image", "generative image"),
    "扩散模型": ("diffusion model", "diffusion models"),
    "提示学习": ("prompt learning", "prompt tuning", "in-context learning"),
    "指令微调": ("instruction tuning", "instruction fine-tuning"),
    "参数高效微调": ("parameter-efficient fine-tuning", "peft"),
    "微调": ("fine-tuning", "fine tuning"),
    "知识增强": ("knowledge augmented", "knowledge-enhanced"),
    "幻觉": ("hallucination", "factuality", "faithfulness"),
    "可解释性": ("explainability", "interpretability"),
    "公平性": ("fairness", "bias evaluation"),
    "鲁棒性": ("robustness", "robustness evaluation"),
    "安全": ("safety", "trustworthy", "red teaming"),
    "基准": ("benchmark", "benchmarking", "evaluation benchmark"),
    "数据集": ("dataset", "datasets", "corpus"),
    "综述": ("survey", "review", "systematic review"),
    "领域自适应": ("domain adaptation", "domain generalization"),
    "跨模态": ("cross-modal", "cross modality"),
    "视觉编码器": ("vision encoder", "visual encoder"),
    "多模态大模型": ("multimodal large language model", "mllm", "multimodal llm"),
    "多模态大语言模型": ("multimodal large language model", "mllm", "multimodal llm"),
}

# Facets let the discovery plan explain *why* a query was expanded and make
# it possible to retrieve adjacent work without replacing the user's wording.
# The map is intentionally small and curated: high precision terms are more
# useful here than a noisy general thesaurus.
SEARCH_FACET_ALIASES = {
    "对象": {
        "多模态": ("multimodal", "vision-language"),
        "视觉语言模型": ("vision-language model", "vision language model", "vlm"),
        "多模态大模型": ("multimodal large language model", "mllm"),
        "视频": ("video", "video understanding"),
        "图像": ("image", "image understanding"),
        "文本": ("text", "language"),
        "机器人": ("robotics", "robot learning"),
        "医疗": ("medical", "clinical", "healthcare"),
    },
    "方法": {
        "推理": ("reasoning", "inference"),
        "检索增强": ("retrieval augmented", "retrieval-augmented generation", "rag"),
        "微调": ("fine-tuning", "parameter-efficient fine-tuning"),
        "提示": ("prompting", "prompt tuning", "in-context learning"),
        "扩散": ("diffusion", "diffusion model"),
        "强化学习": ("reinforcement learning", "rl"),
        "知识": ("knowledge", "knowledge graph"),
    },
    "任务": {
        "问答": ("question answering", "qa"),
        "生成": ("generation", "generative"),
        "分类": ("classification", "recognition"),
        "检索": ("retrieval", "search"),
        "摘要": ("summarization", "summary"),
        "对齐": ("alignment", "preference optimization"),
        "规划": ("planning", "decision making"),
    },
    "评价": {
        "基准": ("benchmark", "evaluation"),
        "数据集": ("dataset", "benchmark dataset"),
        "鲁棒性": ("robustness", "stress testing"),
        "安全": ("safety", "trustworthiness"),
        "幻觉": ("hallucination", "factuality", "faithfulness"),
    },
}

SEARCH_DEPTHS = {"focused", "balanced", "deep"}
DISCOVERY_MODES = {"balanced", "latest", "foundations", "explore"}


def relevance_tokens(value: str) -> set[str]:
    raw = (value or "").lower()
    words = re.findall(r"[a-z0-9][a-z0-9_-]{2,}|[\u4e00-\u9fff]{2,}", raw)
    terms = {w.strip("_-") for w in words if w.strip("_-") not in REL_STOPWORDS}
    # Chinese titles rarely use spaces.  Keep the complete phrase for
    # explainability, then add bounded bi/tri-grams so a query such as
    # “多模态推理” can match “多模态模型推理” without an embedding service.
    for run in re.findall(r"[\u4e00-\u9fff]{2,}", raw):
        if len(run) > 2 and run not in REL_STOPWORDS:
            for width in (2, 3):
                if len(run) < width:
                    continue
                terms.update(run[index:index + width] for index in range(len(run) - width + 1))
    return {term for term in terms if term not in REL_STOPWORDS}


def expanded_relevance_terms(value: str) -> set[str]:
    """Return original and curated bridge terms for multilingual ranking."""
    raw = clean_text(value, 2000)
    terms = set(relevance_tokens(raw))
    lowered = raw.casefold()
    for concept, aliases in SEARCH_CONCEPT_ALIASES.items():
        if concept.casefold() in lowered:
            terms.update(relevance_tokens(" ".join(aliases[:3])))
    for facet in extract_search_facets(raw).values():
        terms.update(relevance_tokens(" ".join(facet.get("expansions", [])[:4])))
    return terms


def extract_search_facets(query: str) -> dict:
    """Extract conservative research facets from a mixed-language question."""
    raw = clean_text(query, 1000)
    lowered = raw.casefold()
    facets = {}
    for facet, terms in SEARCH_FACET_ALIASES.items():
        hits = []
        expansions = []
        for term, aliases in terms.items():
            if term.casefold() in lowered:
                hits.append(term)
                expansions.extend(aliases)
            elif re.search(r"\b" + re.escape(term.casefold()) + r"\b", lowered):
                hits.append(term)
                expansions.extend(aliases)
        if hits:
            facets[facet] = {"hits": list(dict.fromkeys(hits)), "expansions": list(dict.fromkeys(expansions))[:8]}
    return facets


def _bridge_query_terms(raw: str) -> str:
    """Replace known Chinese/English concepts in one pass, longest first."""
    candidate = raw
    candidate = re.sub(r"(?<=[A-Za-z0-9])(?=[\u4e00-\u9fff])", " ", candidate)
    candidate = re.sub(r"(?<=[\u4e00-\u9fff])(?=[A-Za-z0-9])", " ", candidate)
    replacements = []
    for concept, aliases in SEARCH_CONCEPT_ALIASES.items():
        if concept.casefold() in candidate.casefold() and aliases:
            replacements.append((concept, aliases[0]))
    for concept, alias in sorted(replacements, key=lambda pair: len(pair[0]), reverse=True):
        candidate = re.sub(re.escape(concept), alias, candidate, count=1, flags=re.IGNORECASE)
    candidate = re.sub(r"(?<=[A-Za-z0-9])(?=[\u4e00-\u9fff])", " ", candidate)
    candidate = re.sub(r"(?<=[\u4e00-\u9fff])(?=[A-Za-z0-9])", " ", candidate)
    return clean_text(candidate, 1000)


def _bridge_non_latin_terms(raw: str) -> str:
    """Bridge only Chinese terms, preserving intentional English aliases."""
    candidate = raw
    candidate = re.sub(r"(?<=[A-Za-z0-9])(?=[\u4e00-\u9fff])", " ", candidate)
    candidate = re.sub(r"(?<=[\u4e00-\u9fff])(?=[A-Za-z0-9])", " ", candidate)
    replacements = []
    for concept, aliases in SEARCH_CONCEPT_ALIASES.items():
        if re.search(r"[\u4e00-\u9fff]", concept) and concept.casefold() in candidate.casefold() and aliases:
            replacements.append((concept, aliases[0]))
    for concept, alias in sorted(replacements, key=lambda pair: len(pair[0]), reverse=True):
        candidate = re.sub(re.escape(concept), alias, candidate, count=1, flags=re.IGNORECASE)
    candidate = re.sub(r"(?<=[A-Za-z0-9])(?=[\u4e00-\u9fff])", " ", candidate)
    candidate = re.sub(r"(?<=[\u4e00-\u9fff])(?=[A-Za-z0-9])", " ", candidate)
    return clean_text(candidate, 1000)


def search_query_variants(query: str, max_variants: int = 6, depth: str = "balanced") -> list[dict]:
    """Build a deterministic, recall-oriented search plan.

    The primary wording is always retained.  Additional variants are simple
    provider-compatible phrases, so the union can be deduplicated across
    arXiv, OpenAlex, Crossref and Europe PMC without provider-specific syntax.
    ``focused`` keeps calls cheap, ``deep`` adds high-signal survey/benchmark
    lanes, and ``balanced`` is the default for long-running topics.
    """
    raw = clean_text(query, 1000)
    if not raw:
        return []
    depth = depth if depth in SEARCH_DEPTHS else "balanced"
    cap = max(1, min(int(max_variants), 12))
    if depth == "deep":
        cap = max(cap, 12)
    # Reserve room for the deep-discovery lanes; otherwise a broad alias list
    # could crowd out evaluation, limitations and frontier entry points.
    alias_limit = max(2, cap - 6) if depth == "deep" else cap
    variants = [{"id": "primary", "query": raw, "kind": "原始问题", "reason": "保留你的原始检索表达", "lane": "primary"}]
    seen = {raw.casefold()}

    def add(candidate: str, kind: str, reason: str, lane: str):
        candidate = clean_text(candidate, 1000)
        key = candidate.casefold()
        if not candidate or key in seen or len(variants) >= cap:
            return False
        seen.add(key)
        variants.append({"id": f"variant-{len(variants)}", "query": candidate, "kind": kind, "reason": reason, "lane": lane})
        return True

    bridge = _bridge_query_terms(raw)
    if bridge.casefold() != raw.casefold():
        add(bridge, "英文桥接", "把已识别的中文术语桥接到英文索引表达", "bridge")

    lowered = raw.casefold()
    # One-term substitutions preserve the remaining context, which is safer
    # than replacing the entire question with a generic synonym.
    for concept, aliases in SEARCH_CONCEPT_ALIASES.items():
        if concept.casefold() not in lowered:
            continue
        for alias in aliases[:2]:
            candidate = re.sub(re.escape(concept), alias, raw, count=1, flags=re.IGNORECASE)
            candidate = _bridge_non_latin_terms(candidate)
            add(candidate, "概念别名", f"用“{alias}”补召回“{concept}”的论文", "alias")
        if len(variants) >= alias_limit:
            break

    facets = extract_search_facets(raw)
    if depth != "focused":
        facet_terms = []
        for item in facets.values():
            facet_terms.extend(item["expansions"][:2])
        if facet_terms:
            add(" ".join(dict.fromkeys(facet_terms[:4])), "概念骨架", "按对象、方法、任务和评价词重组检索骨架", "facets")
    if depth == "deep":
        base = bridge if bridge.casefold() != raw.casefold() else raw
        add(f"{base} survey", "综述入口", "补充综述与系统性地图，优先建立领域全貌", "survey")
        add(f"{base} benchmark", "基准入口", "补充基准、数据集与评测论文", "benchmark")
        add(f"{base} empirical study", "实证入口", "补充实证比较和失败分析", "evidence")
        add(f"{base} dataset evaluation", "数据集评测入口", "补充数据集、评测协议和可比较实验", "evaluation")
        add(f"{base} limitations failure analysis", "局限与失败入口", "主动寻找边界条件、失败案例和负结果", "limitations")
        add(f"{base} state of the art", "前沿综述入口", "补充领域近期最佳结果与比较表", "frontier")
    return variants[:cap]


def candidate_identity(record: dict) -> str:
    """Build a stable per-source identity for merging variant hits."""
    doi = norm_doi(record.get("doi", ""))
    if doi:
        return "doi:" + doi
    arxiv = norm_arxiv(record.get("arxiv_id", ""))
    if arxiv:
        return "arxiv:" + arxiv
    title = title_key(record.get("title", ""))
    year = record.get("year") or ""
    if title:
        return f"title:{title}:{year}"
    external = clean_text(record.get("external_id", ""), 300).casefold()
    return "external:" + external if external else "record:" + hashlib.sha1(json.dumps(record, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()


def title_similarity(left: str, right: str) -> float:
    """Compare normalized titles without treating different editions as equal."""
    def terms(value: str) -> set[str]:
        normalized = title_key(value)
        found = set(normalized.split())
        for run in re.findall(r"[\u4e00-\u9fff]{2,}", normalized):
            found.update(run[index:index + 2] for index in range(max(0, len(run) - 1)))
        return found
    left_terms = terms(left)
    right_terms = terms(right)
    if not left_terms or not right_terms:
        return 0.0
    return len(left_terms & right_terms) / max(1, len(left_terms | right_terms))


def merge_search_records(records: list[dict]) -> tuple[list[dict], int]:
    """Merge exact and near-identical hits while preserving editions.

    A fuzzy title match is only allowed when years agree and at least one
    record lacks a strong identifier.  This removes provider punctuation and
    title casing noise while keeping preprint/conference/journal editions
    separate when both carry different DOI/arXiv identifiers.
    """
    merged = {}
    duplicate_count = 0
    for record in records:
        key = candidate_identity(record)
        previous = merged.get(key)
        if previous is None:
            merged[key] = record
            continue
        duplicate_count += 1
        # Prefer the record carrying more evidence, while retaining the
        # original source/query path on the selected item.
        previous_quality = (bool(previous.get("doi") or previous.get("arxiv_id")), len(previous.get("abstract", "")), len(previous.get("authors", "")))
        current_quality = (bool(record.get("doi") or record.get("arxiv_id")), len(record.get("abstract", "")), len(record.get("authors", "")))
        if current_quality > previous_quality:
            merged[key] = {**previous, **record}
    # A second pass catches title punctuation and provider-specific subtitle
    # differences.  The candidate set is bounded by connector page limits.
    keys = list(merged)
    for index, left_key in enumerate(keys):
        left = merged.get(left_key)
        if not left or not left.get("title"):
            continue
        for right_key in keys[index + 1:]:
            right = merged.get(right_key)
            if not right or not right.get("title"):
                continue
            left_year, right_year = left.get("year"), right.get("year")
            if not left_year or not right_year or abs(int(left_year) - int(right_year)) > 1:
                continue
            left_strong = bool(left.get("doi") or left.get("arxiv_id"))
            right_strong = bool(right.get("doi") or right.get("arxiv_id"))
            if left_strong and right_strong:
                continue
            if title_similarity(left["title"], right["title"]) < 0.92:
                continue
            previous_quality = (left_strong, len(left.get("abstract", "")), len(left.get("authors", "")))
            current_quality = (right_strong, len(right.get("abstract", "")), len(right.get("authors", "")))
            winner, loser = (right, left) if current_quality > previous_quality else (left, right)
            merged[left_key] = {
                **loser,
                **winner,
                "_dedup_aliases": sorted(set((left.get("_dedup_aliases") or []) + (right.get("_dedup_aliases") or []) + [left_key, right_key])),
            }
            merged.pop(right_key, None)
            duplicate_count += 1
            left = merged[left_key]
    return list(merged.values()), duplicate_count


def relevance_label(score: int) -> str:
    if score < 10:
        return "待核验"
    if score >= 60:
        return "高相关"
    if score >= 35:
        return "邻近方向"
    return "低相关"


def relevance_token_weight(term: str) -> float:
    """Down-weight short Chinese n-grams while retaining their recall value."""
    if re.fullmatch(r"[\u4e00-\u9fff]+", term or ""):
        if len(term) == 2:
            return 0.35
        if len(term) == 3:
            return 0.60
    return 1.0


def score_relevance(candidate: dict, query: str, known: list[sqlite3.Row], feedback: list[sqlite3.Row] | None = None) -> dict:
    """Return an explainable triage score against a query and library memory."""
    query_terms = relevance_tokens(query)
    expanded_terms = expanded_relevance_terms(query)
    bridge_terms = expanded_terms - query_terms
    title_terms = relevance_tokens(candidate.get("title", ""))
    body_terms = relevance_tokens(" ".join([candidate.get("abstract", ""), candidate.get("authors", "")]))
    title_hits = sorted(expanded_terms & title_terms)
    body_hits = sorted(expanded_terms & body_terms)
    original_title_hits = sorted(query_terms & title_terms)
    bridge_title_hits = sorted(set(title_hits) & bridge_terms)
    score = min(55, round(
        sum(relevance_token_weight(term) for term in original_title_hits) * 22
        + sum(relevance_token_weight(term) for term in bridge_title_hits) * 14
        + sum(relevance_token_weight(term) for term in query_terms & body_terms) * 7
        + sum(relevance_token_weight(term) for term in set(body_hits) & bridge_terms) * 5
    ))
    reasons = []
    if original_title_hits:
        reasons.append("标题命中 " + ", ".join(original_title_hits[:5]))
    if bridge_title_hits:
        reasons.append("标题命中桥接概念 " + ", ".join(bridge_title_hits[:5]))
    if body_hits and not title_hits:
        reasons.append("摘要/作者命中 " + ", ".join(body_hits[:5]))
    phrases = [clean_text(value, 120).casefold() for value in re.findall(r'"([^"\n]+)"', query) if clean_text(value, 120)]
    title_lower = clean_text(candidate.get("title", ""), 2000).casefold()
    abstract_lower = clean_text(candidate.get("abstract", ""), 30000).casefold()
    phrase_hits = [phrase for phrase in phrases if phrase in title_lower or phrase in abstract_lower]
    if phrase_hits:
        score += min(22, 11 * len(phrase_hits))
        reasons.append("精确短语命中 " + ", ".join(phrase_hits[:3]))
    if expanded_terms:
        coverage = len(set(title_hits + body_hits)) / max(1, len(expanded_terms))
        if coverage >= 0.4:
            score += 10
            reasons.append(f"查询概念覆盖 {round(coverage * 100)}%")
    if bridge_title_hits or set(body_hits) & bridge_terms:
        reasons.append("已用中英文概念桥接校正相关度")
    best_overlap = 0
    best_title = ""
    for row in known:
        other_terms = relevance_tokens(" ".join([row["title"] or "", row["abstract"] or ""]))
        if not other_terms or not (title_terms or body_terms):
            continue
        overlap = len((title_terms | body_terms) & other_terms) / max(1, len(title_terms | body_terms))
        if overlap > best_overlap:
            best_overlap, best_title = overlap, row["title"]
    if best_overlap >= 0.35:
        score += min(35, round(best_overlap * 55))
        reasons.append("与库内论文有主题重合" + (f"：{best_title[:42]}" if best_title else ""))
    elif best_overlap >= 0.18:
        score += 12
        reasons.append("与已有主题存在部分重合")
    for row in feedback or []:
        other_terms = relevance_tokens(" ".join([row["title"] or "", row["abstract"] or ""]))
        if not other_terms or not (title_terms or body_terms):
            continue
        overlap = len((title_terms | body_terms) & other_terms) / max(1, len(title_terms | body_terms))
        if overlap >= 0.28 and row["user_decision"] == "relevant":
            score += 12
            reasons.append("根据你的主题反馈加权")
            break
        if overlap >= 0.28 and row["user_decision"] in {"irrelevant", "ignored"}:
            score -= 18
            reasons.append("根据你此前的忽略反馈降权")
            break
    if candidate.get("doi") or candidate.get("arxiv_id"):
        score += 5
    if candidate.get("open_access"):
        score += 2
    score = max(0, min(100, score))
    return {"score": score, "label": relevance_label(score), "reasons": reasons or ["未发现明确词项重合，建议人工快速扫读"]}


def clean_text(value, max_len=30000) -> str:
    return str(value or "").strip()[:max_len]


def normalize_record(record: dict) -> dict:
    doi = norm_doi(record.get("doi", ""))
    arxiv = norm_arxiv(record.get("arxiv_id", ""))
    title = clean_text(record.get("title"), 1000)
    try:
        year = int(record.get("year")) if record.get("year") else None
        if year and not 1800 <= year <= 2200:
            year = None
    except (ValueError, TypeError):
        year = None
    tags = record.get("tags", [])
    if isinstance(tags, str):
        tags = [x.strip() for x in tags.split(",") if x.strip()]
    return {
        "title": title,
        "title_key": title_key(title),
        "authors": clean_text(record.get("authors", ""), 4000),
        "year": year,
        "abstract": clean_text(record.get("abstract", ""), 30000),
        "doi": doi,
        "arxiv_id": arxiv,
        "venue": clean_text(record.get("venue", ""), 1000),
        "url": clean_text(record.get("url", ""), 3000),
        "pdf_url": clean_text(record.get("pdf_url", ""), 3000),
        "status": record.get("status") if record.get("status") in PAPER_STATUSES else "inbox",
        "topic": clean_text(record.get("topic", ""), 300),
        "tags_json": json.dumps(list(dict.fromkeys(tags))[:100], ensure_ascii=False),
        "notes": clean_text(record.get("notes", ""), 100000),
        "is_favorite": 1 if record.get("is_favorite") else 0,
    }


def paper_text(record: dict | sqlite3.Row) -> str:
    """The stable, local text representation used by explainable ranking."""
    getter = record.get if hasattr(record, "get") else lambda key, default="": record[key] if key in record.keys() else default
    tags = getter("tags", []) if isinstance(record, dict) else []
    if isinstance(tags, str):
        tags = [tags]
    return " ".join(str(getter(key, "") or "") for key in ("title", "abstract", "authors", "topic")) + " " + " ".join(tags)


def text_overlap(left: str, right: str) -> dict:
    """Return a symmetric lexical similarity signal with human-readable hits."""
    left_terms = expanded_relevance_terms(left)
    right_terms = expanded_relevance_terms(right)
    if not left_terms or not right_terms:
        return {"score": 0, "hits": []}
    hits = sorted(left_terms & right_terms)
    # Combine coverage of the shorter concept set with a Jaccard penalty for
    # broad abstracts. This keeps a two-term research query meaningful while
    # preventing one shared generic term from looking like a close match.
    coverage = len(hits) / max(1, min(len(left_terms), len(right_terms)))
    jaccard = len(hits) / max(1, len(left_terms | right_terms))
    score = min(100, round((coverage * 0.7 + jaccard * 0.3) * 100))
    return {"score": score, "hits": hits[:8]}


def connection_tier(score: int) -> str:
    if score >= 48:
        return "高相关"
    if score >= 20:
        return "邻近方向"
    return "跨领域线索"


def research_memory(limit: int = 12) -> dict:
    """Build a deterministic research profile and non-repeating queue.

    The profile is intentionally local and inspectable. It can later be
    replaced by embeddings without changing the API contract or losing the
    feedback history accumulated here.
    """
    limit = min(max(int(limit), 1), 50)
    with DB_LOCK, db_session() as db:
        papers = [paper_dict(row) for row in db.execute("SELECT * FROM papers ORDER BY updated_at DESC")]
        queries = [dict(row) for row in db.execute("SELECT * FROM saved_queries ORDER BY active DESC,updated_at DESC")]
        matches = [dict(row) for row in db.execute("SELECT * FROM query_matches")]
        feedback = [dict(row) for row in db.execute("SELECT * FROM learning_feedback")]
    for query in queries:
        query["sources"] = json.loads(query.pop("sources_json", "[]"))
    by_id = {paper["id"]: paper for paper in papers}
    match_by_paper = {}
    for item in matches:
        match_by_paper.setdefault(item["paper_id"], []).append(item)
    feedback_by_paper = {item["paper_id"]: item for item in feedback if item.get("scope") == "global"}

    anchors = [
        paper for paper in papers
        if paper.get("status") == "read" or paper.get("is_favorite") or any(
            item.get("user_decision") == "relevant" for item in match_by_paper.get(paper["id"], [])
        )
    ]
    profile_counter = {}
    for paper in anchors:
        for term in relevance_tokens(paper_text(paper)):
            profile_counter[term] = profile_counter.get(term, 0) + 1
    top_terms = [term for term, _ in sorted(profile_counter.items(), key=lambda pair: (-pair[1], pair[0]))[:12]]
    topic_counts = {}
    for paper in anchors:
        topic = paper.get("topic") or "未分类"
        topic_counts[topic] = topic_counts.get(topic, 0) + 1

    def query_match(candidate):
        best = {"score": 0, "query": "", "hits": []}
        for query in queries:
            result = text_overlap(paper_text(candidate), query.get("query", ""))
            if result["score"] > best["score"]:
                best = {**result, "query": query.get("name") or query.get("query", "")}
        return best

    def anchor_match(candidate):
        best = {"score": 0, "title": "", "hits": []}
        for anchor in anchors:
            result = text_overlap(paper_text(candidate), paper_text(anchor))
            if result["score"] > best["score"]:
                best = {**result, "title": anchor.get("title", "")}
        return best

    candidates = []
    for paper in papers:
        if paper["status"] not in {"inbox", "to_read", "later", "watching"}:
            continue
        global_feedback = feedback_by_paper.get(paper["id"], {})
        if global_feedback.get("decision") == "irrelevant":
            continue
        qmatch = query_match(paper)
        amatch = anchor_match(paper)
        seen = sum(int(item.get("seen_count") or 0) for item in match_by_paper.get(paper["id"], []))
        ignored = sum(item.get("user_decision") in {"irrelevant", "ignored"} for item in match_by_paper.get(paper["id"], []))
        score = round(qmatch["score"] * 0.58 + amatch["score"] * 0.42)
        if paper.get("topic") and paper.get("topic") in topic_counts:
            score += 8
        if seen > 1:
            score -= min(20, (seen - 1) * 5)
        score -= min(30, ignored * 15)
        if not anchors and not queries:
            score = 0
        reasons = []
        if qmatch["score"]:
            reasons.append(f"命中主题：{qmatch['query']}")
        if amatch["score"]:
            reasons.append(f"接近已读论文：{amatch['title'][:36]}")
        if paper.get("topic") and paper.get("topic") in topic_counts:
            reasons.append(f"属于你的研究主题：{paper['topic']}")
        if not seen:
            reasons.append("尚未在自动主题中重复出现")
        if not reasons:
            if not anchors and not queries:
                reasons.append("尚未形成研究画像，按最新入库保留")
            else:
                reasons.append("作为跨领域线索保留，建议先扫读摘要")
        item = {**paper, "recommendation_score": max(0, min(100, score)), "recommendation_reasons": reasons, "seen_count": seen}
        candidates.append(item)
    # Keep fresh arrivals ahead when scores tie, then apply the learned score.
    candidates.sort(key=lambda item: (item.get("updated_at", ""), item.get("title", "")), reverse=True)
    candidates.sort(key=lambda item: item["recommendation_score"], reverse=True)
    selected = []
    topic_slots = {}
    for item in candidates:
        topic = item.get("topic") or "未分类"
        if topic_slots.get(topic, 0) >= 3:
            continue
        selected.append(item)
        topic_slots[topic] = topic_slots.get(topic, 0) + 1
        if len(selected) >= limit:
            break
    return {
        "generated_at": now_iso(),
        "profile": {"anchor_count": len(anchors), "top_terms": top_terms, "top_topics": sorted(topic_counts.items(), key=lambda pair: (-pair[1], pair[0]))[:8], "feedback_count": len(feedback)},
        "recommendations": selected,
    }


def paper_connections(paper_id: str) -> dict:
    """Explain how one paper relates to saved topics and the local library."""
    with DB_LOCK, db_session() as db:
        paper_row = db.execute("SELECT * FROM papers WHERE id=?", (paper_id,)).fetchone()
        if not paper_row:
            raise ValueError("论文不存在")
        paper = paper_dict(paper_row)
        queries = [dict(row) for row in db.execute("SELECT id,name,query,active FROM saved_queries ORDER BY active DESC,updated_at DESC")]
        others = [paper_dict(row) for row in db.execute("SELECT * FROM papers WHERE id<>? AND status<> 'excluded' ORDER BY updated_at DESC", (paper_id,))]
    topics = []
    for query in queries:
        result = text_overlap(paper_text(paper), query.get("query", ""))
        reasons = [f"命中词：{'、'.join(result['hits'][:6])}"] if result["hits"] else ["没有共享的明确词项"]
        topics.append({"id": query["id"], "name": query["name"] or query["query"], "active": bool(query["active"]), "score": result["score"], "tier": connection_tier(result["score"]), "reasons": reasons})
    topics.sort(key=lambda item: (-item["score"], item["name"]))
    related = []
    for other in others:
        result = text_overlap(paper_text(paper), paper_text(other))
        if result["score"] < 10:
            continue
        related.append({"id": other["id"], "title": other["title"], "year": other.get("year"), "status": other.get("status"), "topic": other.get("topic", ""), "score": result["score"], "tier": connection_tier(result["score"]), "hits": result["hits"]})
    related.sort(key=lambda item: (-item["score"], item.get("year") or 0, item["title"]))
    return {"paper_id": paper_id, "topics": topics, "related": related[:12], "generated_at": now_iso()}


def paper_dict(row: sqlite3.Row) -> dict:
    item = dict(row)
    item["tags"] = json.loads(item.pop("tags_json", "[]"))
    item["is_favorite"] = bool(item["is_favorite"])
    return item


def attach_source(db, paper_id: str, source: str, external_id: str = "", query_id: str = "", raw: dict | None = None):
    db.execute("""INSERT INTO source_records(paper_id,source,external_id,query_id,fetched_at,raw_json)
                  VALUES(?,?,?,?,?,?)
                  ON CONFLICT(paper_id,source,external_id,query_id) DO UPDATE SET fetched_at=excluded.fetched_at,raw_json=excluded.raw_json""", (paper_id, source, external_id, query_id, now_iso(), json.dumps(raw or {}, ensure_ascii=False)[:60000]))


def upsert_paper(record: dict, source: str = "manual", external_id: str = "", query_id: str = "", raw: dict | None = None) -> tuple[str, bool]:
    p = normalize_record(record)
    if not p["title"]:
        raise ValueError("论文标题不能为空")
    with DB_LOCK, db_session() as db:
        found = None
        if p["doi"]:
            found = db.execute("SELECT * FROM papers WHERE doi=? LIMIT 1", (p["doi"],)).fetchone()
        if not found and p["arxiv_id"]:
            found = db.execute("SELECT * FROM papers WHERE arxiv_id=? LIMIT 1", (p["arxiv_id"],)).fetchone()
        # Exact normalized title + year is a conservative duplicate guard only when a strong identifier is absent.
        if not found and not p["doi"] and not p["arxiv_id"] and p["year"]:
            found = db.execute("SELECT * FROM papers WHERE title_key=? AND year=? LIMIT 1", (p["title_key"], p["year"])).fetchone()
            if not found:
                # Provider subtitles and punctuation can differ while the
                # work has no DOI/arXiv ID yet.  Require a very high title
                # overlap and the same publication year before merging.
                for candidate in db.execute("SELECT * FROM papers WHERE year=? ORDER BY updated_at DESC LIMIT 200", (p["year"],)).fetchall():
                    if title_similarity(p["title"], candidate["title"]) >= 0.92:
                        found = candidate
                        break
        if found:
            pid = found["id"]
            # Fill gaps in bibliographic fields without overwriting user notes/status/topic.
            for field in ("authors", "abstract", "doi", "arxiv_id", "venue", "url", "pdf_url"):
                if p[field] and not found[field]:
                    db.execute(f"UPDATE papers SET {field}=?,updated_at=? WHERE id=?", (p[field], now_iso(), pid))
            attach_source(db, pid, source, external_id, query_id, raw)
            record_audit(db, "paper.merged", "paper", pid, {"source": source, "query_id": query_id, "external_id": external_id})
            return pid, False
        pid = str(uuid.uuid4())
        cols = ["id", *p.keys(), "created_at", "updated_at"]
        vals = [pid, *p.values(), now_iso(), now_iso()]
        db.execute(f"INSERT INTO papers({','.join(cols)}) VALUES({','.join('?' for _ in cols)})", vals)
        attach_source(db, pid, source, external_id or p["doi"] or p["arxiv_id"], query_id, raw)
        record_audit(db, "paper.created", "paper", pid, {"source": source, "query_id": query_id})
        return pid, True


def http_json(url: str, timeout=20) -> dict:
    req = Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json"})
    with urlopen(req, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8", "replace"))


def sync_openalex_references(paper_id: str) -> dict:
    with DB_LOCK, db_session() as db:
        paper = db.execute("SELECT id,title,doi,arxiv_id FROM papers WHERE id=?", (paper_id,)).fetchone()
    if not paper:
        raise ValueError("论文不存在")
    if not paper["doi"]:
        raise ValueError("该论文还没有 DOI；目前 OpenAlex 引用扩展需要 DOI")
    work_url = "https://api.openalex.org/works/https://doi.org/" + quote(paper["doi"], safe="")
    work = http_json(work_url, timeout=25)
    referenced = work.get("referenced_works") or []
    observed = now_iso()
    with DB_LOCK, db_session() as db:
        for target in referenced:
            external_id = clean_text(target, 300)
            if not external_id:
                continue
            db.execute("""INSERT INTO citation_edges(source_paper_id,target_external_id,provider,discovered_at,last_seen_at,raw_json)
                VALUES(?,?,?,?,?,?) ON CONFLICT(source_paper_id,target_external_id,provider) DO UPDATE SET last_seen_at=excluded.last_seen_at""",
                (paper_id, external_id, "openalex", observed, observed, "{}"))
        rows = [dict(r) for r in db.execute("SELECT target_external_id,provider,discovered_at,last_seen_at FROM citation_edges WHERE source_paper_id=? ORDER BY target_external_id", (paper_id,))]
    return {"paper_id": paper_id, "provider": "OpenAlex", "count": len(rows), "references": rows, "synced_at": observed}


def expand_openalex_relations(paper_id: str, limit: int = 24) -> dict:
    """Discover backward, forward and semantically related works from OpenAlex.

    This is an explicit user action because citation expansion can make several
    network requests.  New works enter the normal inbox and are still subject
    to the same conservative deduplication rules as keyword search.
    """
    limit = min(max(int(limit), 1), 60)
    with DB_LOCK, db_session() as db:
        paper = db.execute("SELECT id,title,doi,arxiv_id FROM papers WHERE id=?", (paper_id,)).fetchone()
        source_id = db.execute("SELECT external_id FROM source_records WHERE paper_id=? AND source='openalex' AND external_id<>'' ORDER BY fetched_at DESC LIMIT 1", (paper_id,)).fetchone()
    if not paper:
        raise ValueError("论文不存在")
    if paper["doi"]:
        work_url = "https://api.openalex.org/works/https://doi.org/" + quote(paper["doi"], safe="")
    elif source_id and str(source_id[0]).strip():
        work_url = "https://api.openalex.org/works/" + quote(str(source_id[0]).rstrip("/").split("/")[-1], safe="")
    else:
        raise ValueError("该论文没有 DOI 或 OpenAlex 标识，暂时无法扩展引用关系")
    work = http_json(work_url, timeout=25)
    work_id = str(work.get("id", "")).rstrip("/").split("/")[-1]
    relation_ids = []
    for relation, ids in (("引用", work.get("referenced_works") or []), ("相似", work.get("related_works") or [])):
        for target in ids:
            key = str(target).rstrip("/").split("/")[-1]
            if key and key != work_id and key not in {item[1] for item in relation_ids}:
                relation_ids.append((relation, key))
    cited_url = work.get("cited_by_api_url", "")
    if cited_url:
        try:
            cited = http_json(cited_url + ("&" if "?" in cited_url else "?") + urlencode({"per-page": min(limit, 25), "sort": "publication_date:desc"}), timeout=25)
            for item in cited.get("results", []):
                key = str(item.get("id", "")).rstrip("/").split("/")[-1]
                if key and key != work_id and key not in {item[1] for item in relation_ids}:
                    relation_ids.append(("被引用", key))
        except (HTTPError, URLError, TimeoutError, OSError, ValueError):
            # Forward citation support is best effort; backward/related work
            # expansion should remain useful when this endpoint is unavailable.
            pass
    relation_ids = relation_ids[:limit]
    candidates = []
    for relation, key in relation_ids:
        try:
            item = http_json("https://api.openalex.org/works/" + quote(key, safe=""), timeout=20)
        except (HTTPError, URLError, TimeoutError, OSError, ValueError):
            continue
        title = clean_text(item.get("title", ""), 1000)
        if not title:
            continue
        inverted = item.get("abstract_inverted_index") or {}
        words = [(int(position), word) for word, positions in inverted.items() for position in (positions or [])]
        primary = item.get("primary_location") or {}
        venue = ((primary.get("source") or {}).get("display_name", ""))
        doi = norm_doi(item.get("doi", ""))
        candidates.append({
            "relation": relation,
            "openalex_id": item.get("id", ""),
            "title": title,
            "authors": ", ".join((entry.get("author") or {}).get("display_name", "") for entry in (item.get("authorships") or [])[:12]),
            "year": item.get("publication_year"),
            "abstract": " ".join(word for _, word in sorted(words)),
            "doi": doi,
            "venue": venue,
            "url": item.get("doi") or item.get("id", ""),
            "pdf_url": (primary.get("pdf") or {}).get("url", "") or "",
            "source": "openalex",
            "external_id": item.get("id", "") or doi,
            "type": "journal-article",
        })
    created = duplicates = 0
    for record in candidates:
        _, is_new = upsert_paper(record, source="openalex", external_id=record.get("external_id", ""), raw={"relation": record["relation"], "seed_paper_id": paper_id})
        created += int(is_new)
        duplicates += int(not is_new)
    with DB_LOCK, db_session() as db:
        record_audit(db, "discovery.expanded", "paper", paper_id, {"candidates": len(candidates), "created": created, "duplicates": duplicates})
    return {"paper_id": paper_id, "provider": "OpenAlex", "candidates": candidates, "created": created, "duplicates": duplicates, "count": len(candidates), "expanded_at": now_iso()}


def extract_attachment_pages(attachment_id: str) -> dict:
    """Extract page text as a rebuildable, quality-labelled derived artifact."""
    try:
        from pypdf import PdfReader
        extractor = "pypdf"
    except ImportError:
        try:
            from PyPDF2 import PdfReader
            extractor = "PyPDF2"
        except ImportError as exc:
            raise ValueError("PDF 文本提取需要可选依赖 pypdf；请运行 pip install pypdf") from exc
    with DB_LOCK, db_session() as db:
        attachment = db.execute("SELECT id,paper_id,stored_name,original_name FROM attachments WHERE id=?", (attachment_id,)).fetchone()
    if not attachment:
        raise ValueError("附件不存在")
    target = FILES_DIR / Path(attachment["stored_name"]).name
    if not target.is_file():
        raise ValueError("附件文件不存在，可能需要从备份恢复")
    try:
        reader = PdfReader(str(target))
        if getattr(reader, "is_encrypted", False):
            try:
                reader.decrypt("")
            except Exception as exc:
                raise ValueError("PDF 已加密，无法在没有密码的情况下提取文本") from exc
        pages = []
        for index, page in enumerate(reader.pages, start=1):
            raw = page.extract_text() or ""
            text = clean_text(raw.replace("\x00", ""), 500_000)
            chars = len(text.strip())
            quality = "good" if chars >= 160 else ("low" if chars else "empty")
            pages.append({"page_number": index, "text": text, "char_count": chars, "quality": quality, "text_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest()})
    except ValueError:
        raise
    except Exception as exc:
        raise ValueError(f"PDF 解析失败：{str(exc)[:300]}") from exc
    extracted_at = now_iso()
    with DB_LOCK, db_session() as db:
        db.execute("DELETE FROM document_pages WHERE attachment_id=?", (attachment_id,))
        for item in pages:
            db.execute("INSERT INTO document_pages(attachment_id,paper_id,page_number,text,char_count,quality,extractor,text_sha256,extracted_at) VALUES(?,?,?,?,?,?,?,?,?)", (attachment_id, attachment["paper_id"], item["page_number"], item["text"], item["char_count"], item["quality"], extractor, item["text_sha256"], extracted_at))
        record_audit(db, "document.extracted", "attachment", attachment_id, {"paper_id": attachment["paper_id"], "pages": len(pages), "nonempty_pages": sum(item["quality"] != "empty" for item in pages), "extractor": extractor})
    return {"attachment_id": attachment_id, "paper_id": attachment["paper_id"], "filename": attachment["original_name"], "page_count": len(pages), "nonempty_pages": sum(item["quality"] != "empty" for item in pages), "characters": sum(item["char_count"] for item in pages), "extractor": extractor, "extracted_at": extracted_at}


def extract_paper_documents(paper_id: str) -> dict:
    with DB_LOCK, db_session() as db:
        attachments = [dict(row) for row in db.execute("SELECT id FROM attachments WHERE paper_id=? ORDER BY added_at", (paper_id,))]
    if not attachments:
        raise ValueError("这篇论文还没有本地 PDF 附件")
    results = [extract_attachment_pages(item["id"]) for item in attachments]
    return {"paper_id": paper_id, "attachments": results, "page_count": sum(item["page_count"] for item in results), "characters": sum(item["characters"] for item in results), "extracted_at": max(item["extracted_at"] for item in results)}


def extraction_summary(paper_id: str) -> dict:
    with DB_LOCK, db_session() as db:
        rows = [dict(row) for row in db.execute("SELECT attachment_id,MAX(extracted_at) AS extracted_at,COUNT(*) AS page_count,SUM(char_count) AS characters,SUM(quality='good') AS good_pages,SUM(quality='low') AS low_pages,SUM(quality='empty') AS empty_pages,MAX(extractor) AS extractor FROM document_pages WHERE paper_id=? GROUP BY attachment_id", (paper_id,))]
        attachments = db.execute("SELECT COUNT(*) FROM attachments WHERE paper_id=?", (paper_id,)).fetchone()[0]
    return {"paper_id": paper_id, "attachment_count": attachments, "extracted_attachment_count": len(rows), "pages": rows, "page_count": sum(int(row["page_count"] or 0) for row in rows), "characters": sum(int(row["characters"] or 0) for row in rows)}


def search_document_pages(paper_id: str, query: str, limit: int = 20) -> list[dict]:
    query = clean_text(query, 300)
    if not query:
        raise ValueError("请输入页码检索词")
    limit = min(max(int(limit), 1), 100)
    escaped = query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    with DB_LOCK, db_session() as db:
        rows = [dict(row) for row in db.execute("SELECT attachment_id,page_number,text,char_count,quality,extractor,text_sha256,extracted_at FROM document_pages WHERE paper_id=? AND text LIKE ? ESCAPE '\\' ORDER BY page_number,attachment_id LIMIT ?", (paper_id, f"%{escaped}%", limit))]
    needle = query.casefold()
    for row in rows:
        full_text = row.pop("text", "")
        position = full_text.casefold().find(needle)
        if position < 0:
            row["snippet"] = clean_text(full_text, 240)
        else:
            start = max(0, position - 90)
            end = min(len(full_text), position + len(query) + 150)
            prefix = "…" if start else ""
            suffix = "…" if end < len(full_text) else ""
            row["snippet"] = prefix + clean_text(full_text[start:end], 260) + suffix
    return rows


def search_crossref(query: str, limit: int, offset: int = 0) -> list[dict]:
    direct_doi = norm_doi(query) if re.match(r"(?:https?://(?:dx\.)?doi\.org/|doi:\s*)?10\.\d{4,9}/\S+", str(query).strip(), re.I) else ""
    if direct_doi:
        url = "https://api.crossref.org/works/" + quote(direct_doi, safe="")
    else:
        url = "https://api.crossref.org/works?" + urlencode({"query.bibliographic": query, "rows": min(limit, 50), "offset": max(0, offset), "select": "DOI,title,author,published,container-title,URL,abstract,type"})
    data = http_json(url)
    if direct_doi:
        data = {"message": {"items": [data.get("message", {})]}}
    out = []
    for item in data.get("message", {}).get("items", []):
        title = (item.get("title") or [""])[0]
        if not title:
            continue
        title_norm = title_key(title)
        if re.search(r"(?:\.pdf|_supp\d|supplementary|supplement|session details|table of contents|front matter)", title.lower()):
            continue
        if item.get("type") not in {"journal-article", "proceedings-article", "posted-content", "book-chapter", "report"}:
            continue
        query_terms = [] if direct_doi else [term for term in re.findall(r"[a-z0-9]{3,}", query.lower()) if term not in {"and", "or", "the", "for", "with", "from", "via", "using", "based", "model", "models"}]
        title_hits = sum(1 for term in set(query_terms) if term in title_norm)
        abstract_text = re.sub(r"<[^>]+>", " ", item.get("abstract", "")).lower()
        abstract_hits = sum(1 for term in set(query_terms) if term in abstract_text)
        if query_terms and not title_hits and abstract_hits < min(2, len(set(query_terms))):
            continue
        date_parts = item.get("published", {}).get("date-parts", [[]])
        year = date_parts[0][0] if date_parts and date_parts[0] else None
        authors = ", ".join(" ".join(filter(None, [a.get("given", ""), a.get("family", "")])) for a in item.get("author", [])[:12])
        out.append({"title": title, "authors": authors, "year": year, "abstract": abstract_text, "doi": item.get("DOI", ""), "venue": (item.get("container-title") or [""])[0], "url": item.get("URL", ""), "source": "crossref", "external_id": item.get("DOI", ""), "type": item.get("type", ""), "citation_count": item.get("is-referenced-by-count", 0), "open_access": bool((item.get("link") or []))})
    return out


def search_arxiv(query: str, limit: int, offset: int = 0) -> list[dict]:
    # Use the official Atom API. Plain phrases are quoted; advanced syntax can be supplied as an arXiv query.
    arxiv_query = query.strip()
    direct_arxiv = norm_arxiv(arxiv_query) if re.match(r"(?:https?://(?:www\.)?arxiv\.org/(?:abs|pdf)/)?\d{4}\.\d{4,5}(?:v\d+)?$", arxiv_query, re.I) else ""
    if direct_arxiv:
        arxiv_query = "id_list:" + direct_arxiv
    elif not re.search(r"\b(AND|OR|ANDNOT)\b|\b(all|ti|au|abs|cat):", arxiv_query, re.I):
        arxiv_query = f'all:"{arxiv_query}"'
    url = "https://export.arxiv.org/api/query?" + urlencode({"search_query": arxiv_query, "start": max(0, offset), "max_results": min(limit, 50), "sortBy": "submittedDate", "sortOrder": "descending"})
    req = Request(url, headers={"User-Agent": USER_AGENT})
    with urlopen(req, timeout=25) as response:
        body = response.read()
    root = ET.fromstring(body)
    ns = {"a": "http://www.w3.org/2005/Atom", "arxiv": "http://arxiv.org/schemas/atom"}
    out = []
    for entry in root.findall("a:entry", ns):
        title = " ".join((entry.findtext("a:title", default="", namespaces=ns)).split())
        if not title:
            continue
        link = entry.find("a:id", ns)
        abs_url = link.text.strip() if link is not None and link.text else ""
        arxiv_external_id = abs_url.rsplit("/", 1)[-1]
        arxiv_id = norm_arxiv(arxiv_external_id)
        authors = ", ".join(a.findtext("a:name", default="", namespaces=ns) for a in entry.findall("a:author", ns))
        published = entry.findtext("a:published", default="", namespaces=ns)
        pdf = next((x.get("href", "") for x in entry.findall("a:link", ns) if x.get("title") == "pdf"), "")
        out.append({"title": title, "authors": authors, "year": int(published[:4]) if published[:4].isdigit() else None, "abstract": " ".join(entry.findtext("a:summary", default="", namespaces=ns).split()), "arxiv_id": arxiv_id, "arxiv_version": arxiv_external_id, "venue": "arXiv preprint", "url": abs_url, "pdf_url": pdf or ("https://arxiv.org/pdf/" + quote(arxiv_external_id)), "source": "arxiv", "external_id": arxiv_external_id, "type": "preprint", "open_access": True})
    return out


def search_openalex(query: str, limit: int, offset: int = 0) -> list[dict]:
    """Search OpenAlex for broad, date-sorted scholarly coverage.

    OpenAlex is used as a metadata connector only. Its work records often
    include DOI, venue and an inverted abstract index, which we normalize to
    the same paper shape as the other connectors.
    """
    page = (max(0, offset) // max(1, limit)) + 1
    url = "https://api.openalex.org/works?" + urlencode({
        "search": clean_text(query, 500),
        "per-page": min(max(int(limit), 1), 50),
        "page": page,
        "sort": "publication_date:desc",
        "mailto": "local@example.invalid",
    })
    data = http_json(url)
    out = []
    for item in data.get("results", []):
        title = clean_text(item.get("title", ""), 1000)
        if not title:
            continue
        inverted = item.get("abstract_inverted_index") or {}
        abstract_words = []
        for word, positions in inverted.items():
            for position in positions or []:
                abstract_words.append((int(position), word))
        abstract = " ".join(word for _, word in sorted(abstract_words))
        authors = ", ".join(
            (author.get("author") or {}).get("display_name", "")
            for author in (item.get("authorships") or [])[:12]
            if (author.get("author") or {}).get("display_name")
        )
        primary = item.get("primary_location") or {}
        source = primary.get("source") or {}
        year = item.get("publication_year")
        doi = norm_doi(item.get("doi", ""))
        external_id = item.get("id", "") or doi
        out.append({
            "title": title,
            "authors": authors,
            "year": year,
            "abstract": abstract,
            "doi": doi,
            "venue": source.get("display_name", "") or "",
            "url": item.get("doi") or item.get("id", ""),
            "pdf_url": (primary.get("pdf") or {}).get("url", "") or "",
            "source": "openalex",
            "external_id": external_id,
            "type": clean_text(item.get("type", ""), 100),
            "citation_count": int(item.get("cited_by_count") or 0),
            "open_access": bool((primary.get("is_oa") or False) or (primary.get("pdf") or {}).get("url")),
            "is_retracted": bool(item.get("is_retracted")),
        })
    return out


def search_europepmc(query: str, limit: int, offset: int = 0) -> list[dict]:
    """Search Europe PMC's stable REST API for biomedical and life-science work."""
    page_size = min(max(int(limit), 1), 100)
    page = max(1, (max(0, int(offset)) // page_size) + 1)
    url = "https://www.ebi.ac.uk/europepmc/webservices/rest/search?" + urlencode({
        "query": clean_text(query, 500),
        "format": "json",
        "resultType": "core",
        "pageSize": page_size,
        "page": page,
        "sort": "CITED desc",
    })
    data = http_json(url, timeout=25)
    out = []
    for item in (data.get("resultList") or {}).get("result", []):
        title = clean_text(item.get("title", ""), 1000)
        if not title:
            continue
        year = item.get("pubYear") or (item.get("firstPublicationDate", "")[:4] if item.get("firstPublicationDate") else None)
        try:
            year = int(year) if year else None
        except (TypeError, ValueError):
            year = None
        external_id = clean_text(item.get("id", ""), 300)
        pmid = clean_text(item.get("pmid", ""), 100)
        pmcid = clean_text(item.get("pmcid", ""), 100)
        doi = norm_doi(item.get("doi", ""))
        article_url = f"https://europepmc.org/article/{item.get('source', 'MED')}/{external_id}" if external_id else "https://europepmc.org/"
        pdf_url = f"https://europepmc.org/articles/{pmcid}?pdf=render" if pmcid else ""
        out.append({
            "title": title,
            "authors": clean_text(item.get("authorString", ""), 4000),
            "year": year,
            "abstract": clean_text(item.get("abstractText", ""), 30000),
            "doi": doi,
            "venue": clean_text(item.get("journalTitle", ""), 1000),
            "url": article_url,
            "pdf_url": pdf_url,
            "source": "europepmc",
            "external_id": external_id or doi or pmid,
            "type": "journal-article",
            "open_access": bool(item.get("isOpenAccess") == "Y" or pmcid),
            "pmid": pmid,
            "pmcid": pmcid,
            "citation_count": int(item.get("citedByCount") or 0),
        })
    return out


def search_semanticscholar(query: str, limit: int, offset: int = 0) -> list[dict]:
    """Search Semantic Scholar when its public quota is available.

    The connector is deliberately optional: Semantic Scholar can return 429
    without an API key.  The federated run records that source as failed while
    preserving results from every other connector.
    """
    fields = "title,authors,year,abstract,externalIds,venue,url,openAccessPdf,publicationTypes"
    url = "https://api.semanticscholar.org/graph/v1/paper/search?" + urlencode({
        "query": clean_text(query, 500),
        "limit": min(max(int(limit), 1), 100),
        "offset": max(0, int(offset)),
        "fields": fields,
    })
    req = Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json"})
    with urlopen(req, timeout=25) as response:
        data = json.loads(response.read().decode("utf-8", "replace"))
    out = []
    for item in data.get("data", []):
        title = clean_text(item.get("title", ""), 1000)
        if not title:
            continue
        external = item.get("externalIds") or {}
        doi = norm_doi(external.get("DOI", ""))
        arxiv_id = norm_arxiv(external.get("ArXiv", ""))
        open_pdf = item.get("openAccessPdf") or {}
        out.append({
            "title": title,
            "authors": ", ".join((author or {}).get("name", "") for author in (item.get("authors") or [])[:12]),
            "year": item.get("year"),
            "abstract": clean_text(item.get("abstract", ""), 30000),
            "doi": doi,
            "arxiv_id": arxiv_id,
            "venue": clean_text(item.get("venue", ""), 1000),
            "url": item.get("url", "") or (f"https://www.semanticscholar.org/paper/{item.get('paperId', '')}" if item.get("paperId") else ""),
            "pdf_url": open_pdf.get("url", ""),
            "source": "semanticscholar",
            "external_id": item.get("paperId", "") or doi or arxiv_id,
            "type": ((item.get("publicationTypes") or [""])[0] or "").lower(),
            "open_access": bool(open_pdf.get("url")),
            "citation_count": int(item.get("citationCount") or 0),
        })
    return out


def search_dblp(query: str, limit: int, offset: int = 0) -> list[dict]:
    """Search DBLP's keyless computer-science bibliography API."""
    url = "https://dblp.org/search/publ/api?" + urlencode({
        "q": clean_text(query, 500),
        "h": min(max(int(limit), 1), 100),
        "f": max(0, int(offset)),
        "format": "json",
    })
    data = http_json(url, timeout=25)
    hits = ((data.get("result") or {}).get("hits") or {}).get("hit", [])
    if isinstance(hits, dict):
        hits = [hits]
    out = []
    for hit in hits:
        info = hit.get("info") or {}
        title = clean_text(info.get("title", ""), 1000).rstrip(".")
        if not title:
            continue
        authors = info.get("authors") or {}
        author_items = authors.get("author", []) if isinstance(authors, dict) else authors
        if isinstance(author_items, dict):
            author_items = [author_items]
        author_names = []
        for author in author_items or []:
            if isinstance(author, dict):
                author_names.append(clean_text(author.get("text") or author.get("name") or "", 200))
            else:
                author_names.append(clean_text(author, 200))
        doi = norm_doi(info.get("doi", ""))
        year = info.get("year")
        try:
            year = int(year) if year else None
        except (TypeError, ValueError):
            year = None
        entry_type = clean_text(info.get("type", ""), 200).lower()
        out.append({
            "title": title,
            "authors": ", ".join(name for name in author_names if name),
            "year": year,
            "abstract": "",
            "doi": doi,
            "venue": clean_text(info.get("venue", ""), 1000),
            "url": clean_text(info.get("ee") or info.get("url") or "", 3000),
            "source": "dblp",
            "external_id": clean_text(info.get("key") or info.get("url") or doi, 500),
            "type": entry_type,
            "open_access": False,
        })
    return out


def _openreview_value(content: dict, key: str, default=""):
    value = (content or {}).get(key, default)
    if isinstance(value, dict):
        return value.get("value", default)
    return value


def search_openreview(query: str, limit: int, offset: int = 0) -> list[dict]:
    """Search OpenReview notes for current conference and workshop papers.

    OpenReview is intentionally optional.  Its public API changes more often
    than the archival indexes, so an unavailable endpoint is surfaced as a
    source-level error while the other connectors continue normally.
    """
    page_size = min(max(int(limit), 1), 100)
    params = {
        "limit": page_size,
        "offset": max(0, int(offset)),
        "sort": "tmdate:desc",
        "content.title": clean_text(query, 500),
    }
    url = "https://api2.openreview.net/notes?" + urlencode(params)
    data = http_json(url, timeout=25)
    notes = data.get("notes") or data.get("results") or []
    out = []
    for note in notes:
        content = note.get("content") or {}
        title = clean_text(_openreview_value(content, "title"), 1000)
        if not title:
            continue
        abstract = clean_text(_openreview_value(content, "abstract"), 30000)
        authors = _openreview_value(content, "authors", [])
        if isinstance(authors, str):
            authors = [authors]
        author_names = [clean_text(author, 200) for author in (authors or []) if clean_text(author, 200)]
        timestamp = note.get("pdate") or note.get("cdate") or note.get("tmdate")
        try:
            year = int(datetime.fromtimestamp(float(timestamp) / 1000, tz=timezone.utc).year) if timestamp else None
        except (TypeError, ValueError, OSError, OverflowError):
            year = None
        forum = clean_text(note.get("forum") or note.get("id") or "", 300)
        invitation = clean_text(note.get("invitation") or "", 500)
        note_id = clean_text(note.get("id") or forum, 500)
        url = "https://openreview.net/forum?id=" + quote(forum or note_id, safe="") if (forum or note_id) else "https://openreview.net/"
        out.append({
            "title": title,
            "authors": ", ".join(author_names[:12]),
            "year": year,
            "abstract": abstract,
            "venue": clean_text(_openreview_value(content, "venue") or invitation.rsplit("/", 1)[-1], 1000),
            "url": url,
            "source": "openreview",
            "external_id": note_id,
            "type": "conference-paper",
            "open_access": True,
            "openreview_id": note_id,
        })
    return out


SOURCE_SEARCH = {
    "crossref": search_crossref,
    "arxiv": search_arxiv,
    "openalex": search_openalex,
    "europepmc": search_europepmc,
    "semanticscholar": search_semanticscholar,
    "dblp": search_dblp,
    "openreview": search_openreview,
}


def library_relation_variants(query: str, limit: int = 3) -> list[dict]:
    """Build bounded title seeds from the local library for neighbourhood search."""
    if not clean_text(query, 1000):
        return []
    with DB_LOCK, db_session() as db:
        rows = [paper_dict(row) for row in db.execute("SELECT * FROM papers WHERE status <> 'excluded' ORDER BY updated_at DESC LIMIT 400")]
    ranked = []
    for paper in rows:
        overlap = text_overlap(query, paper_text(paper))
        if overlap["score"] >= 18 and paper.get("title"):
            ranked.append((overlap["score"], paper))
    ranked.sort(key=lambda item: (-item[0], item[1].get("updated_at", "")), reverse=False)
    variants = []
    for index, (score, paper) in enumerate(ranked[:max(1, min(int(limit), 5))], start=1):
        variants.append({
            "id": f"relation-{index}",
            "query": clean_text(paper["title"], 500),
            "kind": "馆藏邻域",
            "reason": f"沿本地论文扩展相似、引用与后续工作（主题重合 {score}）",
            "lane": "relations",
        })
    return variants


def library_term_variants(query: str, limit: int = 2) -> list[dict]:
    """Learn terminology from the user's accepted/read library.

    This is a small local expansion pass: it discovers the vocabulary a
    researcher actually uses over time, without sending notes or full text to
    a remote model.  Terms already present in the query are excluded.
    """
    raw = clean_text(query, 1000)
    if not raw:
        return []
    with DB_LOCK, db_session() as db:
        rows = [paper_dict(row) for row in db.execute("SELECT * FROM papers WHERE status IN ('read','reading','to_read','watching') OR is_favorite=1 ORDER BY updated_at DESC LIMIT 300")]
    query_terms = expanded_relevance_terms(raw)
    counter = {}
    for paper in rows:
        for term in relevance_tokens(paper_text(paper)):
            if term in query_terms or len(term) < 3 or term in REL_STOPWORDS:
                continue
            counter[term] = counter.get(term, 0) + 1
    learned = [term for term, count in sorted(counter.items(), key=lambda item: (-item[1], item[0])) if count >= 2][:max(1, min(int(limit), 4))]
    if not learned:
        return []
    return [{
        "id": f"memory-{index}",
        "query": clean_text(f"{raw} {term}", 1000),
        "kind": "馆藏术语学习",
        "reason": f"从你的已读/收藏论文学习术语“{term}”，寻找同方向的新表达",
        "lane": "memory",
    } for index, term in enumerate(learned, start=1)]


def search_query_plan(query: str, sources: list[str], options: dict | None = None) -> dict:
    """Create a transparent search plan before network calls are made."""
    options = options or {}
    raw = clean_text(query, 1000)
    normalized_options = normalize_search_options(options)
    quoted = [clean_text(value, 200) for value in re.findall(r'"([^"\n]+)"', raw) if clean_text(value, 200)]
    # Keep words inside an exact phrase as concepts as well; the phrase is
    # preserved separately so connectors can explain both signals.
    terms = sorted(relevance_tokens(raw), key=lambda term: (-len(term), term))
    expanded_terms = sorted(expanded_relevance_terms(raw), key=lambda term: (-len(term), term))
    variants = search_query_variants(raw, max_variants=12 if normalized_options.get("search_depth") == "deep" else 8, depth=normalized_options.get("search_depth", "balanced")) if normalized_options.get("expand_concepts", True) else [{"id": "primary", "query": raw, "kind": "原始问题", "reason": "按设置仅使用原始检索表达", "lane": "primary"}]
    if normalized_options.get("expand_relations"):
        relation_variants = library_relation_variants(raw)
        if relation_variants:
            variants = [variants[0], *relation_variants, *variants[1:]]
    if normalized_options.get("adaptive_expansion", True) and normalized_options.get("discovery_mode") in {"explore", "latest"}:
        learned_variants = library_term_variants(raw)
        if learned_variants:
            variants = [variants[0], *learned_variants, *variants[1:]]
    if normalized_options.get("discovery_mode") == "latest":
        base = _bridge_query_terms(raw)
        variants.append({"id": f"variant-{len(variants)}", "query": clean_text(f"{base} recent advances", 1000), "kind": "前沿入口", "reason": "补充近期进展、最新方法和技术演化", "lane": "frontier"})
    elif normalized_options.get("discovery_mode") == "foundations":
        variants.append({"id": f"variant-{len(variants)}", "query": clean_text(f"{raw} seminal foundational", 1000), "kind": "基础入口", "reason": "寻找奠基工作、经典基线和早期定义", "lane": "foundations"})
    elif normalized_options.get("discovery_mode") == "explore":
        variants.append({"id": f"variant-{len(variants)}", "query": clean_text(f"{raw} adjacent interdisciplinary", 1000), "kind": "跨领域入口", "reason": "主动探索相邻学科和可迁移方法", "lane": "adjacent"})
    # Keep the plan bounded even when relation and memory lanes are both on.
    variants = variants[:16]
    source_strategy = {
        "arxiv": "最新预印本与计算机科学方法",
        "openalex": "跨学科覆盖、引用与出版元数据",
        "crossref": "期刊/会议 DOI 与正式发表记录",
        "europepmc": "医学、生命科学与开放全文线索",
        "semanticscholar": "语义检索、作者与相似工作（受公开配额影响）",
        "dblp": "计算机科学会议、期刊与作者索引",
        "openreview": "开放评审会议与 workshop 的最新投稿",
    }
    active_sources = [source for source in sources if source in SOURCE_SEARCH]
    return {
        "original_query": raw,
        "concept_terms": terms[:24],
        "expanded_concept_terms": expanded_terms[:36],
        "facets": extract_search_facets(raw),
        "exact_phrases": quoted,
        "query_variants": variants,
        "expansion_count": max(0, len(variants) - 1),
        "coverage_layers": ["原始问题"] + (["英文桥接/概念别名"] if len(variants) > 1 else []) + (["馆藏论文邻域"] if normalized_options.get("expand_relations") and any(item.get("lane") == "relations" for item in variants) else []) + (["馆藏术语学习"] if any(item.get("lane") == "memory" for item in variants) else []) + (["综述/基准/实证入口", "综述/基准/实证/失败分析入口"] if normalized_options.get("search_depth") == "deep" else []) + (["前沿/相邻领域入口"] if normalized_options.get("discovery_mode") in {"latest", "explore"} else []),
        "sources": [{"id": source, "role": source_strategy.get(source, "学术元数据来源")} for source in active_sources],
        "filters": normalized_options,
        "strategy": "原始问题、概念桥接、领域入口与可选馆藏邻域并行 → 强标识/近题名去重 → 多源 Reciprocal Rank Fusion → 相关性、前沿度、长期新颖性与多样性重排",
        "ranking": {"method": "reciprocal-rank-fusion + explainable lexical triage + MMR diversity", "source_weights": SOURCE_RANK_WEIGHTS},
    }


def normalize_search_options(options: dict | None) -> dict:
    options = options or {}
    result = {}
    for key in ("author", "venue", "exclude_terms", "work_type", "sort", "search_depth", "discovery_mode"):
        value = clean_text(options.get(key, ""), 200)
        if value:
            result[key] = value
    for key in ("year_from", "year_to"):
        value = options.get(key)
        try:
            if value not in (None, ""):
                result[key] = min(2200, max(1800, int(value)))
        except (TypeError, ValueError):
            continue
    if result.get("year_from") and result.get("year_to") and result["year_from"] > result["year_to"]:
        result["year_from"], result["year_to"] = result["year_to"], result["year_from"]
    if result.get("sort") not in {"relevance", "newest", "oldest", "novelty", "foundations"}:
        result["sort"] = "relevance"
    if result.get("search_depth") not in SEARCH_DEPTHS:
        result["search_depth"] = "balanced"
    if result.get("discovery_mode") not in DISCOVERY_MODES:
        result["discovery_mode"] = "balanced"
    expand_value = options.get("expand_concepts", True)
    if isinstance(expand_value, str):
        expand_value = expand_value.casefold() not in {"0", "false", "off", "no", "否"}
    result["expand_concepts"] = bool(expand_value)
    for key, default in (("suppress_seen", False), ("include_open_access", False), ("expand_relations", False), ("diversity", True), ("adaptive_expansion", True)):
        value = options.get(key, default)
        if isinstance(value, str):
            value = value.casefold() not in {"0", "false", "off", "no", "否"}
        result[key] = bool(value)
    return result


def record_matches_search_options(record: dict, options: dict) -> bool:
    exclude_terms = [item.casefold() for item in re.split(r"[,;\n]+", options.get("exclude_terms", "")) if item.strip()]
    if exclude_terms:
        haystack = " ".join(str(record.get(key, "") or "") for key in ("title", "abstract", "authors", "venue")).casefold()
        if any(term in haystack for term in exclude_terms):
            return False
    year = record.get("year")
    if options.get("year_from") and (not year or int(year) < options["year_from"]):
        return False
    if options.get("year_to") and (not year or int(year) > options["year_to"]):
        return False
    author = options.get("author", "").casefold()
    if author and author not in str(record.get("authors", "")).casefold():
        return False
    venue = options.get("venue", "").casefold()
    if venue and venue not in str(record.get("venue", "")).casefold():
        return False
    work_type = options.get("work_type", "").casefold()
    actual_type = str(record.get("type", "")).casefold()
    source = str(record.get("source", "")).casefold()
    if work_type == "journal" and not any(token in actual_type for token in ("journal", "article")):
        return False
    if work_type == "conference" and not any(token in actual_type or token in str(record.get("venue", "")).casefold() for token in ("conference", "proceeding", "symposium", "workshop")):
        return False
    if work_type == "review" and "review" not in actual_type and "review" not in str(record.get("title", "")).casefold():
        return False
    if work_type == "preprint" and "preprint" not in actual_type and source != "arxiv" and "posted" not in actual_type:
        return False
    if options.get("include_open_access") and not record.get("open_access"):
        return False
    return True


SOURCE_RANK_WEIGHTS = {
    "openalex": 1.00,
    "semanticscholar": 1.12,
    "arxiv": 0.98,
    "openreview": 1.08,
    "crossref": 0.92,
    "europepmc": 1.00,
    "dblp": 0.90,
}


def rank_fusion_score(signal: dict) -> int:
    """Turn per-source ranks into an explainable reciprocal-rank score."""
    contributions = signal.get("rrf", [])
    if not contributions:
        return 0
    total = sum(float(item.get("weight", 1.0)) / (1.0 + max(0, int(item.get("rank", 0))) / 10.0) for item in contributions)
    # A first-place result from one reliable source is useful; confirmation by
    # a second source quickly raises confidence but never dominates relevance.
    score = round(min(100.0, total * 45.0))
    return max(0, score)


def diversify_results(results: list[dict], limit: int = 80) -> list[dict]:
    """Apply bounded MMR re-ranking so a page covers multiple sub-areas.

    This is lexical by design and therefore works offline.  It uses the same
    normalized terms as the explainable ranker, so the reason for a broadened
    result remains inspectable instead of hiding a black-box embedding.
    """
    if len(results) < 3:
        return results
    candidates = list(results)
    selected = []
    first_pass = min(max(int(limit), 20), len(candidates))
    while candidates and len(selected) < first_pass:
        best_index, best_value, best_penalty = 0, -10**9, 0
        for index, item in enumerate(candidates):
            base = float(item.get("discovery_score") or item.get("relevance_score") or 0)
            penalty = 0.0
            if selected:
                similarities = [text_overlap(paper_text(item), paper_text(other))["score"] for other in selected[-18:]]
                penalty = max(similarities or [0]) * 0.30
                if item.get("venue") and item.get("venue") == selected[-1].get("venue"):
                    penalty += 4
            value = base - penalty
            if value > best_value:
                best_index, best_value, best_penalty = index, value, penalty
        item = candidates.pop(best_index)
        item["diversity_penalty"] = round(best_penalty, 2)
        item["diversity_score"] = round(max(0.0, float(item.get("discovery_score") or item.get("relevance_score") or 0) - best_penalty), 2)
        selected.append(item)
    # The tail is still returned, preserving the existing API's full result
    # set while making the visible top of the page less redundant.
    selected.extend(candidates)
    return selected


def run_query(query: str, sources: list[str], limit: int = 20, query_id: str = "", scheduled: bool = False, name: str = "", options: dict | None = None) -> dict:
    q = clean_text(query, 1000)
    sources = [s for s in sources if s in SOURCE_NAMES and s in SOURCE_SEARCH]
    if not q or not sources:
        raise ValueError("需要检索词和至少一个有效来源")
    search_options = normalize_search_options(options)
    plan = search_query_plan(q, sources, search_options)
    run_id = str(uuid.uuid4())
    started = now_iso()
    with DB_LOCK, db_session() as db:
        db.execute("INSERT INTO runs(id,query_id,query_name,status,started_at,sources_json,is_scheduled) VALUES(?,?,?,?,?,?,?)", (run_id, query_id, name or q, "running", started, json.dumps(sources), int(scheduled)))
        record_audit(db, "sync.started", "run", run_id, {"query_id": query_id, "sources": sources, "scheduled": bool(scheduled)})
    details, new_count, duplicate_count = [], 0, 0
    paper_ids = []
    paper_paths = {}
    paper_signals = {}
    paper_rank_signals = {}
    result_created = {}
    errors = []
    for source in sources:
        try:
            page_size = min(max(int(limit), 1), 50)
            fetch_size = 50 if search_options else page_size
            # Saved topics fetch a few pages so a burst of new papers cannot
            # hide everything after the first 50 results. Ad-hoc searches stay
            # lighter and fetch one page.
            max_pages = 3 if query_id or scheduled else (2 if search_options else 1)
            all_records = []
            variant_details = []
            variants = plan.get("query_variants") or [{"id": "primary", "query": q, "kind": "原始问题", "reason": "保留你的原始检索表达", "lane": "primary"}]
            if source == "semanticscholar":
                # Semantic Scholar already performs semantic expansion and its
                # public quota is the tightest connector budget.
                variants = variants[:1] + [item for item in variants[1:] if item.get("lane") == "relations"][:2]
            else:
                # Keep long-running topics under public connector rate limits
                # while retaining the full plan for the most recall-oriented
                # source. The primary query always receives full pagination.
                variant_caps = {"arxiv": 12 if search_options.get("search_depth") == "deep" else 6, "openalex": 10 if search_options.get("search_depth") == "deep" else 5, "crossref": 8 if search_options.get("search_depth") == "deep" else 4, "europepmc": 6 if search_options.get("search_depth") == "deep" else 3, "dblp": 8 if search_options.get("search_depth") == "deep" else 4, "openreview": 8 if search_options.get("search_depth") == "deep" else 4}
                cap = variant_caps.get(source, 4)
                relation_variants = [item for item in variants[1:] if item.get("lane") == "relations"][:2]
                regular_variants = [item for item in variants[1:] if item.get("lane") != "relations"]
                variants = [variants[0], *relation_variants, *regular_variants][:cap]
            for variant_index, variant in enumerate(variants):
                variant_records = []
                # Expansion queries add recall, while the primary query keeps
                # the user's normal pagination and saved-query depth.
                variant_pages = max_pages if variant_index == 0 else 1
                variant_fetch_size = fetch_size if variant_index == 0 else min(fetch_size, 30)
                for page in range(variant_pages):
                    try:
                        batch = SOURCE_SEARCH[source](variant["query"], variant_fetch_size, page * variant_fetch_size)
                    except TypeError:
                        # Keep compatibility with simple test/custom connectors
                        # that still expose the original two-argument signature.
                        batch = SOURCE_SEARCH[source](variant["query"], variant_fetch_size)
                    batch = [dict(item, _search_variant=variant["id"], _search_query=variant["query"], _source_rank=(page * variant_fetch_size) + item_index + 1, _variant_rank=variant_index + 1) for item_index, item in enumerate(batch)]
                    variant_records.extend(batch)
                    if len(batch) < variant_fetch_size:
                        break
                all_records.extend(variant_records)
                variant_filtered = [record for record in variant_records if record_matches_search_options(record, search_options)]
                variant_details.append({
                    "id": variant["id"], "query": variant["query"], "kind": variant.get("kind", ""),
                    "fetched": len(variant_records), "accepted": len(variant_filtered),
                    "filtered": len(variant_records) - len(variant_filtered),
                })
            raw_count = sum(item["fetched"] for item in variant_details)
            # Count filtering on the unique candidate set, so a variant that
            # returns the same work does not inflate the filter diagnostics.
            unique_raw_records, variant_duplicates = merge_search_records(all_records)
            records = [record for record in unique_raw_records if record_matches_search_options(record, search_options)]
            filtered_count = len(unique_raw_records) - len(records)
            raw_paths = {}
            for item in all_records:
                path = {"variant_id": item.get("_search_variant", "primary"), "query": item.get("_search_query", q), "source": source}
                identity = candidate_identity(item)
                if path not in raw_paths.setdefault(identity, []):
                    raw_paths[identity].append(path)
            path_by_identity = {}
            for item in unique_raw_records:
                identities = [candidate_identity(item), *(item.get("_dedup_aliases") or [])]
                paths = []
                for identity in identities:
                    for path in raw_paths.get(identity, []):
                        if path not in paths:
                            paths.append(path)
                path_by_identity[candidate_identity(item)] = paths
            src_new = src_dup = 0
            for rec in records:
                paper_id, created = upsert_paper(rec, source=source, external_id=rec.get("external_id", ""), query_id=query_id, raw=rec)
                if paper_id not in paper_ids:
                    paper_ids.append(paper_id)
                try:
                    citation_count = max(0, int(rec.get("citation_count") or 0))
                except (TypeError, ValueError):
                    citation_count = 0
                signal = paper_signals.setdefault(paper_id, {"citation_count": 0, "open_access": False, "lanes": set()})
                signal["citation_count"] = max(signal["citation_count"], citation_count)
                signal["open_access"] = bool(signal["open_access"] or rec.get("open_access"))
                signal["lanes"].add(next((item.get("lane") for item in variants if item.get("id") == rec.get("_search_variant")), "primary"))
                rank_signal = paper_rank_signals.setdefault(paper_id, {"rrf": [], "sources": set(), "variants": set()})
                rank_signal["rrf"].append({"source": source, "rank": int(rec.get("_source_rank") or 1), "weight": SOURCE_RANK_WEIGHTS.get(source, 0.8)})
                rank_signal["sources"].add(source)
                rank_signal["variants"].add(rec.get("_search_variant", "primary"))
                existing_paths = paper_paths.setdefault(paper_id, [])
                for path in path_by_identity.get(candidate_identity(rec), []):
                    if path not in existing_paths:
                        existing_paths.append(path)
                result_created[paper_id] = result_created.get(paper_id, False) or created
                if created:
                    src_new += 1
                else:
                    src_dup += 1
            new_count += src_new
            duplicate_count += src_dup + variant_duplicates
            details.append({"source": source, "status": "ok", "fetched": raw_count, "accepted": len(records), "filtered": filtered_count, "variant_duplicates": variant_duplicates, "new": src_new, "duplicates": src_dup + variant_duplicates, "variants": variant_details, "error": ""})
        except (HTTPError, URLError, TimeoutError, ET.ParseError, ValueError, OSError) as exc:
            message = f"{source}: {str(exc)[:500]}"
            errors.append(message)
            details.append({"source": source, "status": "error", "fetched": 0, "accepted": 0, "filtered": 0, "variant_duplicates": 0, "new": 0, "duplicates": 0, "variants": [], "error": message})
    status = "partial" if errors and len(errors) < len(sources) else ("failed" if errors else "success")
    error_text = "\n".join(errors)
    with DB_LOCK, db_session() as db:
        db.execute("UPDATE runs SET status=?,completed_at=?,new_count=?,duplicate_count=?,source_details_json=?,error=? WHERE id=?", (status, now_iso(), new_count, duplicate_count, json.dumps(details, ensure_ascii=False), error_text, run_id))
        record_audit(db, "sync.completed", "run", run_id, {"status": status, "new_count": new_count, "duplicate_count": duplicate_count, "error": bool(error_text)})
        if query_id:
            # A partial/failed source run is retried soon; a successful run
            # follows the user's normal cadence.
            delay_hours = 1 if errors else max(1, int(get_query_cadence(query_id)))
            db.execute("UPDATE saved_queries SET last_run_at=?,next_run_at=?,updated_at=? WHERE id=?", (now_iso(), (datetime.now(timezone.utc) + timedelta(hours=delay_hours)).replace(microsecond=0).isoformat(), now_iso(), query_id))
    with DB_LOCK, db_session() as db:
        results = []
        known_rows = db.execute("SELECT title,abstract FROM papers WHERE id NOT IN ({})".format(",".join("?" for _ in paper_ids) if paper_ids else "''"), tuple(paper_ids)).fetchall()
        query_seen_ids = set()
        if query_id:
            query_seen_ids = {row[0] for row in db.execute("SELECT paper_id FROM query_matches WHERE query_id=?", (query_id,)).fetchall()}
        feedback_rows = db.execute("""SELECT p.title,p.abstract,qm.user_decision FROM query_matches qm
            JOIN papers p ON p.id=qm.paper_id WHERE qm.query_id=? AND qm.user_decision IN ('relevant','irrelevant','ignored')""", (query_id,)).fetchall() if query_id else []
        feedback_rows += db.execute("""SELECT p.title,p.abstract,lf.decision AS user_decision FROM learning_feedback lf
            JOIN papers p ON p.id=lf.paper_id WHERE lf.scope='global' AND lf.decision IN ('relevant','irrelevant')""").fetchall()
        for paper_id in paper_ids:
            row = db.execute("SELECT * FROM papers WHERE id=?", (paper_id,)).fetchone()
            if row:
                paper = paper_dict(row)
                paper["sources"] = [dict(source_row) for source_row in db.execute("SELECT source,external_id,fetched_at FROM source_records WHERE paper_id=? ORDER BY fetched_at DESC", (paper_id,))]
                paper["discovery_paths"] = paper_paths.get(paper_id, [])
                signals = paper_signals.get(paper_id, {"citation_count": 0, "open_access": False, "lanes": set()})
                paper["citation_count"] = int(signals.get("citation_count") or 0)
                paper["open_access"] = bool(signals.get("open_access"))
                paper["discovery_lanes"] = sorted(signals.get("lanes") or [])
                rank_signal = paper_rank_signals.get(paper_id, {"rrf": [], "sources": set(), "variants": set()})
                paper["rank_fusion_score"] = rank_fusion_score(rank_signal)
                paper["rank_sources"] = sorted(rank_signal.get("sources") or [])
                paper["rank_paths"] = len(rank_signal.get("rrf") or [])
                results.append(paper)
    query_terms = [term for term in re.findall(r"[a-z0-9]{3,}", q.lower()) if term not in {"and", "or", "the", "for", "with", "from", "via", "using", "based", "model", "models"}]
    current_year = datetime.now(timezone.utc).year
    for paper in results:
        title = title_key(paper["title"])
        abstract = (paper.get("abstract") or "").lower()
        title_hits = [term for term in query_terms if term in title]
        abstract_hits = [term for term in query_terms if term in abstract]
        paper["match_reason"] = "标题命中：" + "、".join(dict.fromkeys(title_hits)) if title_hits else ("摘要命中：" + "、".join(dict.fromkeys(abstract_hits)) if abstract_hits else "来源检索结果；请人工核对相关性")
        triage = score_relevance(paper, q, known_rows, feedback_rows)
        paper["relevance_score"] = triage["score"]
        paper["relevance_label"] = triage["label"]
        paper["relevance_reasons"] = triage["reasons"]
        # Saved topics remember their own history. A paper already in another
        # topic is still a first discovery for this topic; ad-hoc searches use
        # the global library state as the only available memory.
        paper["seen_before"] = (paper["id"] in query_seen_ids) if query_id else not result_created.get(paper["id"], False)
        paper["seen_status"] = STATUS_LABELS.get(paper.get("status"), paper.get("status", "")) if "STATUS_LABELS" in globals() else paper.get("status", "")
        paper["query_id"] = query_id
        age = max(0, current_year - int(paper["year"])) if paper.get("year") else 12
        paper["recency_score"] = max(0, 100 - min(100, age * 10))
        paper["novelty_score"] = 100 if not paper["seen_before"] else 35
        paper["source_count"] = len({source.get("source") for source in paper.get("sources", [])})
        citation_count = int(paper.get("citation_count") or 0)
        paper["impact_score"] = min(100, round((citation_count ** 0.5) * 10)) if citation_count else 0
        paper["source_quality_score"] = min(100, paper["source_count"] * 25 + (10 if paper.get("doi") else 0) + (8 if paper.get("open_access") else 0))
        paper["coverage_score"] = min(100, round((len(expanded_relevance_terms(q) & (relevance_tokens(paper.get("title", "")) | relevance_tokens(paper.get("abstract", "")))) / max(1, len(expanded_relevance_terms(q)))) * 100))
        paper["library_distance_score"] = max((text_overlap(paper_text(paper), f"{row['title'] or ''} {row['abstract'] or ''}")["score"] for row in known_rows), default=0)
        paper["discovery_class"] = (
            "高相关" if paper["relevance_score"] >= 60 else
            "邻近方向" if paper["relevance_score"] >= 35 else
            "跨领域线索"
        )
        paper["discovery_score"] = round(
            paper["relevance_score"] * 0.52
            + paper["rank_fusion_score"] * 0.18
            + paper["recency_score"] * 0.12
            + paper["source_quality_score"] * 0.08
            + paper["novelty_score"] * 0.10
        )
        paper["discovery_reasons"] = list(paper.get("relevance_reasons", []))
        if paper.get("discovery_paths"):
            path_count = len(paper["discovery_paths"])
            if path_count > 1:
                paper["discovery_reasons"].append(f"多路检索确认：{path_count} 条路径")
            aliases = [path["query"] for path in paper["discovery_paths"] if path.get("variant_id") != "primary"]
            if aliases:
                paper["discovery_reasons"].append("概念变体命中：" + "、".join(dict.fromkeys(aliases))[:120])
        if paper["source_count"] > 1:
            paper["discovery_reasons"].append(f"多源交叉确认：{paper['source_count']} 个来源")
        if paper.get("rank_fusion_score"):
            paper["discovery_reasons"].append(f"融合排序信号：{paper['rank_fusion_score']}（{paper.get('rank_paths', 0)} 条来源/变体路径）")
        if paper.get("discovery_class") == "跨领域线索":
            paper["discovery_reasons"].append("与原问题词面较远，作为跨领域探索线索保留")
        elif paper.get("library_distance_score", 0) >= 48:
            paper["discovery_reasons"].append("与馆藏研究方向高度相连")
        if paper["recency_score"] >= 80:
            paper["discovery_reasons"].append("较新发表记录")
        if paper["seen_before"]:
            paper["discovery_reasons"].append("已在此前轮次出现，降低重复优先级")
        else:
            paper["discovery_reasons"].append("本主题首次发现")
        if paper["citation_count"]:
            paper["discovery_reasons"].append(f"来源记录引用量：{paper['citation_count']}")
        if paper.get("open_access"):
            paper["discovery_reasons"].append("存在开放获取线索")
        lanes = paper.get("discovery_lanes") or []
        if lanes:
            paper["discovery_reasons"].append("召回层：" + "、".join(lanes))
    if query_id and results:
        # Query-specific memory prevents an ignore decision in one topic from
        # hiding the same work from another topic.
        observed_at = now_iso()
        with DB_LOCK, db_session() as db:
            for paper in results:
                existing = db.execute("SELECT first_seen_at,seen_count,user_decision,viewed_at FROM query_matches WHERE query_id=? AND paper_id=?", (query_id, paper["id"])).fetchone()
                if existing:
                    db.execute("""UPDATE query_matches SET last_seen_at=?,seen_count=?,last_run_id=?,score=?,tier=?,explanation_json=?,score_version=?
                                  WHERE query_id=? AND paper_id=?""", (observed_at, existing["seen_count"] + 1, run_id, paper.get("discovery_score", paper["relevance_score"]), paper.get("discovery_class", paper["relevance_label"]), json.dumps(paper.get("discovery_reasons", paper["relevance_reasons"]), ensure_ascii=False), "rankfusion-v2", query_id, paper["id"]))
                    paper["seen_count"] = existing["seen_count"] + 1
                    paper["first_seen_at"] = existing["first_seen_at"]
                    paper["user_decision"] = existing["user_decision"]
                    paper["viewed_at"] = existing["viewed_at"]
                    paper["suppressed"] = existing["user_decision"] in {"irrelevant", "ignored"}
                else:
                    db.execute("""INSERT INTO query_matches(query_id,paper_id,first_seen_at,last_seen_at,seen_count,first_run_id,last_run_id,score,tier,explanation_json,score_version,user_decision,viewed_at)
                                  VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""", (query_id, paper["id"], observed_at, observed_at, 1, run_id, run_id, paper.get("discovery_score", paper["relevance_score"]), paper.get("discovery_class", paper["relevance_label"]), json.dumps(paper.get("discovery_reasons", paper["relevance_reasons"]), ensure_ascii=False), "rankfusion-v2", "new", ""))
                    paper["seen_count"] = 1
                    paper["first_seen_at"] = observed_at
                    paper["user_decision"] = "new"
                    paper["viewed_at"] = ""
                    paper["suppressed"] = False
    suppressed_count = sum(1 for paper in results if paper.get("suppressed"))
    before_suppress_count = len(results)
    if query_id and search_options.get("suppress_seen"):
        results = [paper for paper in results if not paper.get("seen_before") or paper.get("user_decision") == "relevant"]
        suppressed_count = max(suppressed_count, before_suppress_count - len(results))
    sort_mode = search_options.get("sort", "relevance")
    discovery_mode = search_options.get("discovery_mode", "balanced")
    if sort_mode == "newest":
        results.sort(key=lambda item: (item.get("year") or 0, item.get("relevance_score") or 0), reverse=True)
    elif sort_mode == "oldest":
        results.sort(key=lambda item: (item.get("year") or 9999, -(item.get("relevance_score") or 0)))
    elif sort_mode == "novelty":
        results.sort(key=lambda item: (item.get("novelty_score") or 0, item.get("relevance_score") or 0, item.get("year") or 0), reverse=True)
    elif sort_mode == "foundations" or discovery_mode == "foundations":
        results.sort(key=lambda item: (item.get("impact_score") or 0, item.get("relevance_score") or 0, item.get("year") or 0), reverse=True)
    elif discovery_mode == "latest":
        results.sort(key=lambda item: (item.get("recency_score") or 0, item.get("relevance_score") or 0, item.get("source_quality_score") or 0), reverse=True)
    elif discovery_mode == "explore":
        results.sort(key=lambda item: (item.get("relevance_score") or 0, item.get("source_quality_score") or 0, item.get("novelty_score") or 0), reverse=True)
    else:
        results.sort(key=lambda item: (item.get("discovery_score") or 0, item.get("relevance_score") or 0, item.get("year") or 0), reverse=True)
    if search_options.get("diversity", True):
        results = diversify_results(results)
    for index, paper in enumerate(results, start=1):
        paper["search_rank"] = index
    discovery_summary = {
        "high_relevance": sum(1 for paper in results if paper.get("relevance_label") == "高相关"),
        "adjacent": sum(1 for paper in results if paper.get("relevance_label") == "邻近方向"),
        "new_to_topic": sum(1 for paper in results if not paper.get("seen_before")),
        "open_access": sum(1 for paper in results if paper.get("open_access")),
        "with_citations": sum(1 for paper in results if paper.get("citation_count")),
        "lanes": sorted({lane for paper in results for lane in paper.get("discovery_lanes", [])}),
    }
    return {"id": run_id, "status": status, "new_count": new_count, "duplicate_count": duplicate_count, "suppressed_count": suppressed_count, "sources": details, "error": error_text, "papers": results, "plan": plan, "summary": discovery_summary, "accepted_count": len(results), "total_fetched": sum(detail.get("fetched", 0) for detail in details), "total_filtered": sum(detail.get("filtered", 0) for detail in details)}


def get_query_cadence(query_id: str) -> int:
    with DB_LOCK, db_session() as db:
        row = db.execute("SELECT cadence_hours FROM saved_queries WHERE id=?", (query_id,)).fetchone()
        return int(row[0]) if row else 168


def evaluation_summary() -> dict:
    """Compute ranking quality from explicit user judgments.

    Only ``relevant`` and ``irrelevant`` judgments are evaluable labels;
    ``ignored`` and ``later`` remain workflow states and are excluded from
    precision calculations.  The metric is intentionally transparent and
    local so a future embedding ranker can be compared against this baseline.
    """
    with DB_LOCK, db_session() as db:
        rows = db.execute("""SELECT qm.query_id,qm.paper_id,qm.score,qm.user_decision,qm.last_seen_at,
            COALESCE(NULLIF(sq.name,''),sq.query,qm.query_id) AS query_name
            FROM query_matches qm LEFT JOIN saved_queries sq ON sq.id=qm.query_id
            WHERE user_decision IN ('relevant','irrelevant')
            ORDER BY query_id,score DESC,last_seen_at DESC""").fetchall()
    groups = {}
    for row in rows:
        groups.setdefault(row["query_id"], []).append(dict(row))
    per_query = []
    for query_id, items in groups.items():
        ranked = sorted(items, key=lambda item: (item.get("score", 0), item.get("last_seen_at", "")), reverse=True)
        metrics = {"query_id": query_id, "query_name": ranked[0].get("query_name") or query_id, "judged": len(ranked), "relevant": sum(item["user_decision"] == "relevant" for item in ranked)}
        for k in (5, 10):
            top = ranked[:k]
            metrics[f"precision_at_{k}"] = round(sum(item["user_decision"] == "relevant" for item in top) / len(top), 4) if top else None
        per_query.append(metrics)
    judged = len(rows)
    relevant = sum(row["user_decision"] == "relevant" for row in rows)
    result = {
        "status": "ready" if judged >= 5 else "insufficient_samples",
        "judged_matches": judged,
        "relevant_matches": relevant,
        "negative_matches": judged - relevant,
        "query_count": len(per_query),
        "precision_at_5": round(sum(item["precision_at_5"] for item in per_query if item["precision_at_5"] is not None) / max(1, sum(item["precision_at_5"] is not None for item in per_query)), 4) if per_query else None,
        "precision_at_10": round(sum(item["precision_at_10"] for item in per_query if item["precision_at_10"] is not None) / max(1, sum(item["precision_at_10"] is not None for item in per_query)), 4) if per_query else None,
        "judged_precision": round(relevant / judged, 4) if judged else None,
        "per_query": per_query[:50],
    }
    return result


def analytics_summary() -> dict:
    """Build a small, reproducible product/learning dashboard from local facts."""
    now = datetime.now(timezone.utc).replace(microsecond=0)
    horizon = (now - timedelta(days=90)).isoformat()
    month_horizon = (now - timedelta(days=30)).isoformat()
    with DB_LOCK, db_session() as db:
        total = db.execute("SELECT COUNT(*) FROM papers").fetchone()[0]
        status_rows = db.execute("SELECT status,COUNT(*) AS n FROM papers GROUP BY status").fetchall()
        added_rows = db.execute("SELECT created_at FROM papers WHERE created_at>=?", (horizon,)).fetchall()
        read_rows = db.execute("SELECT updated_at FROM papers WHERE status='read' AND updated_at>=?", (horizon,)).fetchall()
        run_rows = db.execute("SELECT status,new_count,duplicate_count,sources_json,source_details_json,started_at,completed_at FROM runs WHERE started_at>=?", (month_horizon,)).fetchall()
        topic_rows = db.execute("SELECT COALESCE(NULLIF(topic,''),'未分类') AS topic,COUNT(*) AS n FROM papers GROUP BY topic ORDER BY n DESC LIMIT 10").fetchall()
        feedback_rows = db.execute("SELECT user_decision,COUNT(*) AS n FROM query_matches GROUP BY user_decision").fetchall()
        match_total = db.execute("SELECT COUNT(*) FROM query_matches").fetchone()[0]
        audit_events_30d = db.execute("SELECT COUNT(*) FROM audit_events WHERE created_at>=?", (month_horizon,)).fetchone()[0]
        schema_row = db.execute("SELECT value FROM app_meta WHERE key='schema_version'").fetchone()
        attachments = db.execute("SELECT COUNT(*) FROM attachments").fetchone()[0]
        active_queries = db.execute("SELECT COUNT(*) FROM saved_queries WHERE active=1").fetchone()[0]
    def week_key(value: str) -> str:
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00")).date().isoformat()
        except (TypeError, ValueError):
            return ""
    weeks = []
    monday = now.date() - timedelta(days=now.date().weekday())
    for index in range(11, -1, -1):
        start = monday - timedelta(days=index * 7)
        weeks.append({"week": start.isoformat(), "added": 0, "read": 0})
    week_map = {item["week"]: item for item in weeks}
    for row in added_rows:
        day = week_key(row["created_at"])
        if day:
            start = datetime.fromisoformat(day).date() - timedelta(days=datetime.fromisoformat(day).date().weekday())
            if start.isoformat() in week_map:
                week_map[start.isoformat()]["added"] += 1
    for row in read_rows:
        day = week_key(row["updated_at"])
        if day:
            start = datetime.fromisoformat(day).date() - timedelta(days=datetime.fromisoformat(day).date().weekday())
            if start.isoformat() in week_map:
                week_map[start.isoformat()]["read"] += 1
    source_health = {}
    detail_runs = 0
    detail_missing_runs = 0
    durations = []
    runs_success = runs_partial = runs_failed = new_count = duplicate_count = 0
    raw_fetched_total = accepted_total = filtered_total = 0
    for row in run_rows:
        status = row["status"]
        runs_success += int(status == "success")
        runs_partial += int(status == "partial")
        runs_failed += int(status == "failed")
        new_count += row["new_count"] or 0
        duplicate_count += row["duplicate_count"] or 0
        try:
            if row["started_at"] and row["completed_at"]:
                duration = (datetime.fromisoformat(row["completed_at"]) - datetime.fromisoformat(row["started_at"])).total_seconds()
                if duration >= 0:
                    durations.append(duration)
        except (TypeError, ValueError):
            pass
        try:
            details = json.loads(row["source_details_json"] or "[]")
        except (TypeError, json.JSONDecodeError):
            details = []
        # Schema 6 and earlier only stored source names. Keep those runs in
        # the window, but do not invent fetched/accepted counts for them.
        if isinstance(details, list) and any(isinstance(detail, dict) for detail in details):
            detail_runs += 1
        else:
            detail_missing_runs += 1
            details = []
        for detail in details:
            if not isinstance(detail, dict):
                continue
            name = detail.get("source", "unknown")
            item = source_health.setdefault(name, {"source": name, "runs": 0, "success": 0, "failed": 0, "fetched": 0, "accepted": 0, "filtered": 0})
            item["runs"] += 1
            item["success"] += int(detail.get("status") == "ok")
            item["failed"] += int(detail.get("status") != "ok")
            item["fetched"] += int(detail.get("fetched") or 0)
            item["accepted"] += int(detail.get("accepted", detail.get("fetched", 0)) or 0)
            item["filtered"] += int(detail.get("filtered", 0) or 0)
            raw_fetched_total += int(detail.get("fetched") or 0)
            accepted_total += int(detail.get("accepted", detail.get("fetched", 0)) or 0)
            filtered_total += int(detail.get("filtered", 0) or 0)
    run_total = len(run_rows)
    evaluation = evaluation_summary()
    feedback_coverage = round((sum(int(row["n"]) for row in feedback_rows if row["user_decision"] in {"relevant", "irrelevant", "ignored"}) / match_total) * 100, 1) if match_total else 0
    dedup_rate = round((duplicate_count / (new_count + duplicate_count)) * 100, 1) if (new_count + duplicate_count) else 0
    acceptance_rate = round((accepted_total / raw_fetched_total) * 100, 1) if raw_fetched_total else 0
    p95 = runtime_metrics_summary().get("p95_ms", 0)
    optimization_actions = []
    if not run_total:
        optimization_actions.append({"priority": "P1", "area": "检索基线", "signal": "尚无同步运行样本", "action": "先保存一个窄主题并运行 3 次，再比较来源成功率、去重率和 Precision@5。", "evidence": "runs_30d=0"})
    if detail_missing_runs:
        optimization_actions.append({"priority": "P1", "area": "数据完整性", "signal": f"{detail_missing_runs} 次历史运行缺少来源详情", "action": "使用新版本重新运行主题以建立可比较的抓取、过滤和接受基线；历史数量保持未知，不回填估算值。", "evidence": "source_details_json=missing"})
    if evaluation.get("status") != "ready":
        optimization_actions.append({"priority": "P1", "area": "质量评测", "signal": f"明确判断样本 {evaluation.get('judged_matches', 0)} 个", "action": "优先标记相关/忽略，样本达到 5 个后再调整排序权重或接入 embedding。", "evidence": "evaluation.status=insufficient_samples"})
    if feedback_coverage < 30 and match_total:
        optimization_actions.append({"priority": "P1", "area": "反馈闭环", "signal": f"反馈覆盖率 {feedback_coverage}%", "action": "在发现页完成首轮人工分诊，避免用未标注数据判断检索质量。", "evidence": f"judged_matches/matches={feedback_coverage}%"})
    if dedup_rate >= 45:
        optimization_actions.append({"priority": "P2", "area": "召回成本", "signal": f"去重率 {dedup_rate}%", "action": "检查查询变体和来源重叠；可降低深度检索频率或保留更强的来源优先级。", "evidence": f"duplicates/(new+duplicates)={dedup_rate}%"})
    if raw_fetched_total and acceptance_rate < 20:
        optimization_actions.append({"priority": "P2", "area": "过滤策略", "signal": f"候选接受率 {acceptance_rate}%", "action": "检查年份、作者、venue、排除词是否过严，并对低摘要覆盖来源单独评估。", "evidence": f"accepted/fetched={acceptance_rate}%"})
    failed_sources = [item["source"] for item in source_health.values() if item.get("runs") and item.get("failed", 0) / max(1, item.get("runs", 0)) >= 0.5]
    if failed_sources:
        optimization_actions.append({"priority": "P1", "area": "连接器可靠性", "signal": "、".join(failed_sources) + " 失败率较高", "action": "暂停或降低该来源频率，确认其余来源成功后再判断是否真的没有新论文。", "evidence": "source_health.failed/runs>=50%"})
    if p95 > 1500:
        optimization_actions.append({"priority": "P1", "area": "性能 SLO", "signal": f"当前 p95 {p95} ms", "action": "优先检查外部连接器超时、检索变体数量和 PDF 派生任务，保持模型调用与核心事务解耦。", "evidence": "runtime.p95_ms>1500"})
    if not optimization_actions:
        optimization_actions.append({"priority": "P3", "area": "持续改进", "signal": "当前指标没有触发异常门槛", "action": "保持每周复盘，使用同一批人工判断比较检索策略版本。", "evidence": "all quality gates within observed thresholds"})
    retrieval_funnel = {
        "fetched": raw_fetched_total,
        "filtered": filtered_total,
        "accepted": accepted_total,
        "new": new_count,
        "duplicates": duplicate_count,
        "filter_rate_pct": round((filtered_total / raw_fetched_total) * 100, 1) if raw_fetched_total else 0,
        "acceptance_rate_pct": acceptance_rate,
        "dedup_rate_pct": dedup_rate,
        "data_quality": "complete" if detail_missing_runs == 0 else "historical_detail_missing",
    }
    data_quality = {
        "status": "complete" if detail_missing_runs == 0 else ("partial" if detail_runs else "historical_detail_missing"),
        "runs_with_details": detail_runs,
        "runs_missing_details": detail_missing_runs,
        "message": "所有观测窗口内的运行都包含来源详情。" if detail_missing_runs == 0 else "部分历史运行只有来源名称，无法恢复抓取/过滤数量；新运行会自动补齐详情。",
    }
    development_cycle = {
        "baseline": "rankfusion-v2 + explainable lexical triage",
        "observation_window_days": 30,
        "feedback_samples": evaluation.get("judged_matches", 0),
        "next_gate": "样本不足" if evaluation.get("status") != "ready" else "比较 Precision@5/10 后再调整模型或权重",
        "gates": {"p95_ms": 1500, "server_error_rate_pct": 1.0, "minimum_judgments": 5},
    }
    return {
        "generated_at": now.isoformat(),
        "metrics": {
            "total_papers": total,
            "backlog": sum(int(row["n"]) for row in status_rows if row["status"] in {"inbox", "to_read", "later"}),
            "reading": next((row["n"] for row in status_rows if row["status"] == "reading"), 0),
            "read": next((row["n"] for row in status_rows if row["status"] == "read"), 0),
            "new_30d": sum(1 for row in added_rows if row["created_at"] >= month_horizon),
            "read_30d": sum(1 for row in read_rows if row["updated_at"] >= month_horizon),
            "runs_30d": run_total,
            "success_rate": round((runs_success / run_total) * 100, 1) if run_total else 0,
            "dedup_rate": dedup_rate,
            "attachments": attachments,
            "active_queries": active_queries,
            "feedback_coverage": feedback_coverage,
            "audit_events_30d": audit_events_30d,
            "avg_run_seconds": round(sum(durations) / len(durations), 2) if durations else 0,
            "raw_fetched_30d": raw_fetched_total,
            "accepted_candidates_30d": accepted_total,
            "filtered_candidates_30d": filtered_total,
            "candidate_acceptance_rate": acceptance_rate,
            "schema_version": schema_row[0] if schema_row else "unknown",
        },
        "status": {row["status"]: row["n"] for row in status_rows},
        "topics": [dict(row) for row in topic_rows],
        "feedback": {row["user_decision"]: row["n"] for row in feedback_rows},
        "runs": {"total": run_total, "success": runs_success, "partial": runs_partial, "failed": runs_failed},
        "source_health": list(source_health.values()),
        "evaluation": evaluation,
        "retrieval_funnel": retrieval_funnel,
        "data_quality": data_quality,
        "optimization_actions": optimization_actions,
        "development_cycle": development_cycle,
        "weekly": weeks,
        "runtime": runtime_metrics_summary(),
        "operational": {"audit_events_30d": audit_events_30d, "avg_run_seconds": round(sum(durations) / len(durations), 2) if durations else 0, "schema_version": schema_row[0] if schema_row else "unknown"},
    }


def health_summary() -> dict:
    """Expose an operator-friendly readiness snapshot without leaking secrets."""
    database = {"status": "ok", "path": str(DB_PATH), "integrity": "ok", "schema_version": ""}
    try:
        with DB_LOCK, db_session() as db:
            integrity = db.execute("PRAGMA integrity_check").fetchone()[0]
            row = db.execute("SELECT value FROM app_meta WHERE key='schema_version'").fetchone()
            database["integrity"] = integrity
            database["schema_version"] = row[0] if row else "unknown"
            database["papers"] = db.execute("SELECT COUNT(*) FROM papers").fetchone()[0]
            database["audit_events"] = db.execute("SELECT COUNT(*) FROM audit_events").fetchone()[0]
            if integrity != "ok":
                database["status"] = "error"
    except Exception as exc:
        database.update({"status": "error", "integrity": str(exc)[:300]})
    scheduler = {"status": "not_started", "started_at": SCHEDULER_STARTED_AT, "last_tick_at": SCHEDULER_LAST_TICK}
    if SCHEDULER_STARTED_AT:
        scheduler["status"] = "starting" if not SCHEDULER_LAST_TICK else "ok"
        if SCHEDULER_LAST_TICK:
            try:
                age = (datetime.now(timezone.utc) - datetime.fromisoformat(SCHEDULER_LAST_TICK)).total_seconds()
                scheduler["age_seconds"] = max(0, round(age))
                if age > 150:
                    scheduler["status"] = "stale"
            except ValueError:
                scheduler["status"] = "unknown"
    latest_backup = ""
    if BACKUP_DIR.exists():
        backups = sorted(BACKUP_DIR.glob("researchdesk-backup-*.zip"), key=lambda item: item.stat().st_mtime, reverse=True)
        if backups:
            latest_backup = datetime.fromtimestamp(backups[0].stat().st_mtime, timezone.utc).replace(microsecond=0).isoformat()
    return {
        "status": "ok" if database["status"] == "ok" else "degraded",
        "ready": database["status"] == "ok",
        "app_version": APP_VERSION,
        "process_started_at": PROCESS_STARTED_AT,
        "generated_at": now_iso(),
        "database": database,
        "scheduler": scheduler,
        "latest_backup_at": latest_backup,
    }


def diagnostics_summary() -> dict:
    """Return a safe release/readiness snapshot for operators and demos.

    This endpoint intentionally combines facts from the health probe, database
    quality checks, connector catalog and process SLOs. It never includes API
    keys, request payloads, notes or PDF contents.
    """
    health = health_summary()
    with DB_LOCK, db_session() as db:
        total_papers = db.execute("SELECT COUNT(*) FROM papers").fetchone()[0]
        missing_abstract = db.execute("SELECT COUNT(*) FROM papers WHERE trim(abstract)='' ").fetchone()[0]
        missing_identity = db.execute("SELECT COUNT(*) FROM papers WHERE trim(doi)='' AND trim(arxiv_id)='' ").fetchone()[0]
        source_observations = db.execute("SELECT COUNT(*) FROM source_records").fetchone()[0]
        duplicate_title_keys = db.execute("SELECT COUNT(*) FROM (SELECT title_key,year,COUNT(*) AS n FROM papers GROUP BY title_key,year HAVING n>1)").fetchone()[0]
        matches = db.execute("SELECT COUNT(*) FROM query_matches").fetchone()[0]
        judged = db.execute("SELECT COUNT(*) FROM query_matches WHERE user_decision IN ('relevant','irrelevant','ignored')").fetchone()[0]
        schema_row = db.execute("SELECT value FROM app_meta WHERE key='schema_version'").fetchone()
    source_catalog = {
        "arxiv": {"role": "最新预印本", "access": "public", "authentication": "none"},
        "openalex": {"role": "跨学科元数据与引用", "access": "public", "authentication": "none"},
        "crossref": {"role": "正式出版 DOI 元数据", "access": "public", "authentication": "none"},
        "europepmc": {"role": "医学与生命科学", "access": "public", "authentication": "none"},
        "semanticscholar": {"role": "语义检索与相似工作", "access": "optional", "authentication": "public quota or key"},
        "dblp": {"role": "计算机科学会议与作者索引", "access": "optional", "authentication": "public; network challenge possible"},
        "openreview": {"role": "开放评审会议与 workshop 最新投稿", "access": "optional", "authentication": "public; endpoint availability varies"},
    }
    return {
        "generated_at": now_iso(),
        "release": {
            "app_version": APP_VERSION,
            "schema_version": schema_row[0] if schema_row else "unknown",
            "python_version": sys.version.split()[0],
            "api_contract": "openapi.yaml",
            "quality_gate": "scripts/verify.ps1",
        },
        "health": health,
        "connectors": source_catalog,
        "data_quality": {
            "papers": total_papers,
            "source_observations": source_observations,
            "missing_abstract": missing_abstract,
            "missing_abstract_pct": round((missing_abstract / total_papers) * 100, 2) if total_papers else 0,
            "missing_strong_identifier": missing_identity,
            "missing_strong_identifier_pct": round((missing_identity / total_papers) * 100, 2) if total_papers else 0,
            "duplicate_title_year_groups": duplicate_title_keys,
            "query_matches": matches,
            "judged_matches": judged,
            "feedback_coverage_pct": round((judged / matches) * 100, 2) if matches else 0,
        },
        "slo": runtime_metrics_summary(),
        "slo_targets": {"p95_ms": 1500, "server_error_rate_pct": 1.0},
    }


def research_briefing(days: int = 7, limit: int = 8) -> dict:
    """Build a local, reproducible research brief for the current window."""
    days = min(max(int(days), 1), 90)
    limit = min(max(int(limit), 1), 20)
    now = datetime.now(timezone.utc).replace(microsecond=0)
    horizon = (now - timedelta(days=days)).isoformat()
    with DB_LOCK, db_session() as db:
        new_rows = [paper_dict(row) for row in db.execute("SELECT * FROM papers WHERE created_at>=? AND status<>'excluded' ORDER BY created_at DESC LIMIT 200", (horizon,))]
        status_rows = [dict(row) for row in db.execute("SELECT status,COUNT(*) AS n FROM papers GROUP BY status")]
        query_rows = [dict(row) for row in db.execute("SELECT id,name,query,active,last_run_at,next_run_at FROM saved_queries ORDER BY active DESC,updated_at DESC")]
        run_rows = [dict(row) for row in db.execute("SELECT status,new_count,duplicate_count,started_at,completed_at FROM runs WHERE started_at>=? ORDER BY started_at DESC", (horizon,))]
        source_rows = [dict(row) for row in db.execute("SELECT sr.source,COUNT(*) AS n FROM source_records sr JOIN papers p ON p.id=sr.paper_id WHERE sr.fetched_at>=? GROUP BY sr.source ORDER BY n DESC", (horizon,))]
    topics = {}
    for paper in new_rows:
        topic = paper.get("topic") or "未分类"
        topics[topic] = topics.get(topic, 0) + 1
    compact = lambda paper: {key: paper.get(key, "") for key in ("id", "title", "authors", "year", "venue", "abstract", "status", "topic", "url", "pdf_url", "doi", "arxiv_id", "created_at", "updated_at")}
    recommendations = research_memory(limit=limit).get("recommendations", [])
    failures = sum(1 for row in run_rows if row.get("status") in {"failed", "partial"})
    active_topics = sum(1 for row in query_rows if row.get("active"))
    status_map = {row["status"]: int(row["n"]) for row in status_rows}
    return {
        "generated_at": now.isoformat(),
        "window_days": days,
        "summary": {
            "new_papers": len(new_rows),
            "backlog": sum(status_map.get(status, 0) for status in ("inbox", "to_read", "later")),
            "reading": status_map.get("reading", 0),
            "read": status_map.get("read", 0),
            "active_topics": active_topics,
            "sync_runs": len(run_rows),
            "partial_or_failed_runs": failures,
        },
        "topic_breakdown": [{"topic": topic, "count": count} for topic, count in sorted(topics.items(), key=lambda pair: (-pair[1], pair[0]))[:12]],
        "source_activity": source_rows,
        "recent_papers": [compact(paper) for paper in new_rows[:limit]],
        "next_reads": [compact(paper) | {"recommendation_score": paper.get("recommendation_score"), "recommendation_reasons": paper.get("recommendation_reasons", [])} for paper in recommendations],
        "attention": (["有来源运行失败或部分失败，请先检查来源健康"] if failures else []) + (["待读积压超过新增量，建议先完成分诊"] if status_map.get("to_read", 0) > len(new_rows) and status_map.get("to_read", 0) > 10 else []),
    }


def scheduler_loop():
    global SCHEDULER_LAST_TICK
    # Persistent due times live in SQLite; if the app was closed, due queries run after restart.
    SCHEDULER_LAST_TICK = now_iso()
    while not STOP_EVENT.wait(45):
        try:
            SCHEDULER_LAST_TICK = now_iso()
            due = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
            with DB_LOCK, db_session() as db:
                rows = db.execute("SELECT * FROM saved_queries WHERE active=1 AND (next_run_at='' OR next_run_at<=?) ORDER BY next_run_at LIMIT 3", (due,)).fetchall()
            for row in rows:
                try:
                    options = json.loads(row["search_options_json"] or "{}")
                except (json.JSONDecodeError, TypeError):
                    options = {}
                try:
                    run_query(row["query"], json.loads(row["sources_json"]), 20, row["id"], True, row["name"], options)
                except Exception as exc:
                    with DB_LOCK, db_session() as db:
                        db.execute("UPDATE saved_queries SET next_run_at=?,updated_at=? WHERE id=?", ((datetime.now(timezone.utc) + timedelta(hours=1)).replace(microsecond=0).isoformat(), now_iso(), row["id"]))
                        db.execute("INSERT INTO runs(id,query_id,query_name,status,started_at,completed_at,error,is_scheduled) VALUES(?,?,?,?,?,?,?,1)", (str(uuid.uuid4()), row["id"], row["name"], "failed", now_iso(), now_iso(), str(exc)[:1000]))
        except Exception:
            # Keep the local app alive if the database or a connector has a transient failure.
            time.sleep(2)


class Handler(BaseHTTPRequestHandler):
    server_version = f"LiteratureDesk/{APP_VERSION}"

    def handle_one_request(self):
        self.request_id = uuid.uuid4().hex[:12]
        self.request_started_perf = time.perf_counter()
        super().handle_one_request()

    def log_message(self, fmt, *args):
        # Local-first app: structured request logs never include bodies or credentials.
        started = getattr(self, "request_started_perf", None)
        duration_ms = round((time.perf_counter() - started) * 1000, 2) if started else None
        message = fmt % args
        status_match = re.search(r"\"\s+(\d{3})\s+", message)
        status = int(status_match.group(1)) if status_match else 0
        record_runtime_request(getattr(self, "command", ""), getattr(self, "path", ""), status, duration_ms or 0)
        print(json.dumps({"ts": now_iso(), "level": "info", "request_id": getattr(self, "request_id", ""), "client": self.address_string(), "duration_ms": duration_ms, "message": message}, ensure_ascii=False), flush=True)

    def send_json(self, value, status=200):
        data = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Request-ID", getattr(self, "request_id", ""))
        self.end_headers()
        self.wfile.write(data)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length > 270 * 1024 * 1024:
            raise ValueError("请求体过大（当前单次上传上限约 270 MB）")
        body = self.rfile.read(length) if length else b"{}"
        return json.loads(body.decode("utf-8"))

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/" or path == "/index.html":
            return self.serve_file(STATIC / "index.html", "text/html; charset=utf-8")
        if path.startswith("/static/"):
            target = (STATIC / path.removeprefix("/static/")).resolve()
            if STATIC.resolve() not in target.parents:
                return self.send_error(404)
            return self.serve_file(target)
        if path.startswith("/files/"):
            name = Path(path.removeprefix("/files/")).name
            target = FILES_DIR / name
            return self.serve_file(target, "application/pdf")
        if path.startswith("/api/backups/"):
            name = Path(path.removeprefix("/api/backups/")).name
            target = BACKUP_DIR / name
            if not name.endswith(".zip") or BACKUP_DIR.resolve() not in target.resolve().parents:
                return self.send_error(404)
            return self.serve_file(target, "application/zip")
        if path == "/api/state":
            return self.get_state()
        if path in {"/api/health", "/api/ready"}:
            health = health_summary()
            return self.send_json(health, 200 if health["ready"] else 503)
        if path == "/api/audit":
            try:
                limit = min(max(int((parse_qs(parsed.query).get("limit") or ["100"])[0]), 1), 500)
            except (TypeError, ValueError):
                limit = 100
            event_type = clean_text((parse_qs(parsed.query).get("event_type") or [""])[0], 120)
            with DB_LOCK, db_session() as db:
                if event_type:
                    rows = [dict(row) for row in db.execute("SELECT * FROM audit_events WHERE event_type=? ORDER BY id DESC LIMIT ?", (event_type, limit))]
                else:
                    rows = [dict(row) for row in db.execute("SELECT * FROM audit_events ORDER BY id DESC LIMIT ?", (limit,))]
            for row in rows:
                try:
                    row["payload"] = json.loads(row.pop("payload_json", "{}"))
                except json.JSONDecodeError:
                    row["payload"] = {}
            return self.send_json(rows)
        if path == "/api/papers":
            return self.get_papers(parse_qs(parsed.query))
        if path == "/api/recommendations":
            try:
                limit = int((parse_qs(parsed.query).get("limit") or ["12"])[0])
            except (TypeError, ValueError):
                limit = 12
            return self.send_json(research_memory(limit))
        if path == "/api/queries":
            with DB_LOCK, db_session() as db:
                rows = [dict(r) for r in db.execute("SELECT * FROM saved_queries ORDER BY active DESC,updated_at DESC")]
            for item in rows:
                item["sources"] = json.loads(item.pop("sources_json"))
                try:
                    item["search_options"] = json.loads(item.pop("search_options_json", "{}") or "{}")
                except json.JSONDecodeError:
                    item["search_options"] = {}
                item["active"] = bool(item["active"])
            return self.send_json(rows)
        if path.startswith("/api/queries/") and path.endswith("/matches"):
            query_id = path.split("/")[3]
            with DB_LOCK, db_session() as db:
                rows = [dict(r) for r in db.execute("""SELECT qm.*,p.title,p.year,p.status
                    FROM query_matches qm JOIN papers p ON p.id=qm.paper_id
                    WHERE qm.query_id=? ORDER BY qm.last_seen_at DESC""", (query_id,))]
            for item in rows:
                item["explanation"] = json.loads(item.pop("explanation_json", "[]"))
            return self.send_json(rows)
        if path.startswith("/api/papers/") and path.endswith("/references"):
            paper_id = path.split("/")[3]
            with DB_LOCK, db_session() as db:
                rows = [dict(r) for r in db.execute("SELECT target_external_id,provider,discovered_at,last_seen_at FROM citation_edges WHERE source_paper_id=? ORDER BY target_external_id", (paper_id,))]
            return self.send_json({"references": rows, "count": len(rows)})
        if path.startswith("/api/papers/") and path.endswith("/connections"):
            try:
                return self.send_json(paper_connections(path.split("/")[3]))
            except ValueError as exc:
                return self.send_json({"error": str(exc)}, 404)
        if path.startswith("/api/papers/") and path.endswith("/extraction"):
            paper_id = path.split("/")[3]
            return self.send_json(extraction_summary(paper_id))
        if path.startswith("/api/papers/") and path.endswith("/pages"):
            paper_id = path.split("/")[3]
            params = parse_qs(parsed.query)
            query = (params.get("q") or [""])[0]
            if not query:
                return self.send_json({"error": "请提供 q 页码检索词"}, 400)
            try:
                limit = int((params.get("limit") or ["20"])[0])
            except (TypeError, ValueError):
                limit = 20
            return self.send_json({"paper_id": paper_id, "query": query, "pages": search_document_pages(paper_id, query, limit)})
        if path == "/api/runs":
            with DB_LOCK, db_session() as db:
                return self.send_json([dict(r) for r in db.execute("SELECT * FROM runs ORDER BY started_at DESC LIMIT 100")])
        if path == "/api/export/json":
            return self.export_json()
        if path == "/api/export/bibtex":
            return self.export_bibtex()
        if path == "/api/analytics":
            return self.send_json(analytics_summary())
        if path == "/api/metrics":
            return self.send_json(runtime_metrics_summary())
        if path == "/api/diagnostics":
            return self.send_json(diagnostics_summary())
        if path == "/api/briefing":
            params = parse_qs(parsed.query)
            try:
                days = int((params.get("days") or ["7"])[0])
            except (TypeError, ValueError):
                days = 7
            try:
                limit = int((params.get("limit") or ["8"])[0])
            except (TypeError, ValueError):
                limit = 8
            return self.send_json(research_briefing(days, limit))
        if path == "/api/evaluation":
            return self.send_json(evaluation_summary())
        if path == "/api/settings/model":
            return self.send_json(model_settings())
        if path == "/api/agent/status":
            settings = model_settings()
            return self.send_json({"configured": settings["api_key_set"], **settings})
        return self.send_error(404)

    def serve_file(self, path: Path, content_type=None):
        if not path.is_file():
            return self.send_error(404)
        data = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type or mimetypes.guess_type(path.name)[0] or "application/octet-stream")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Request-ID", getattr(self, "request_id", ""))
        self.end_headers()
        self.wfile.write(data)

    def get_state(self):
        with DB_LOCK, db_session() as db:
            counts = {r["status"]: r["n"] for r in db.execute("SELECT status,COUNT(*) AS n FROM papers GROUP BY status")}
            total = db.execute("SELECT COUNT(*) FROM papers").fetchone()[0]
            recent = [paper_dict(r) for r in db.execute("SELECT * FROM papers ORDER BY updated_at DESC LIMIT 8")]
            queries = [dict(r) for r in db.execute("SELECT * FROM saved_queries ORDER BY active DESC,updated_at DESC LIMIT 10")]
            runs = [dict(r) for r in db.execute("SELECT * FROM runs ORDER BY started_at DESC LIMIT 8")]
            attachments = db.execute("SELECT COUNT(*) FROM attachments").fetchone()[0]
        for q in queries:
            q["sources"] = json.loads(q.pop("sources_json"))
            try:
                q["search_options"] = json.loads(q.pop("search_options_json", "{}") or "{}")
            except json.JSONDecodeError:
                q["search_options"] = {}
            q["active"] = bool(q["active"])
        return self.send_json({"counts": counts, "total": total, "recent": recent, "queries": queries, "runs": runs, "attachments": attachments, "updated_at": now_iso(), "data_dir": str(DATA_DIR)})

    def get_papers(self, params):
        q = clean_text((params.get("q") or [""])[0], 500)
        status = clean_text((params.get("status") or [""])[0], 40)
        topic = clean_text((params.get("topic") or [""])[0], 300)
        limit = min(max(int((params.get("limit") or ["300"])[0]), 1), 1000)
        clauses, args = [], []
        if q:
            clauses.append("(title LIKE ? OR authors LIKE ? OR abstract LIKE ? OR doi LIKE ? OR topic LIKE ? OR notes LIKE ?)")
            args.extend([f"%{q}%"] * 6)
        if status:
            clauses.append("status=?")
            args.append(status)
        if topic:
            clauses.append("topic=?")
            args.append(topic)
        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        with DB_LOCK, db_session() as db:
            rows = [paper_dict(r) for r in db.execute(f"SELECT * FROM papers{where} ORDER BY is_favorite DESC,updated_at DESC LIMIT ?", (*args, limit))]
            for paper in rows:
                paper["sources"] = [dict(r) for r in db.execute("SELECT source,external_id,fetched_at FROM source_records WHERE paper_id=? ORDER BY fetched_at DESC", (paper["id"],))]
                paper["attachments"] = [dict(r) for r in db.execute("SELECT id,original_name,stored_name,sha256,byte_size,added_at FROM attachments WHERE paper_id=?", (paper["id"],))]
                paper["ai_artifacts"] = [dict(r) for r in db.execute("SELECT id,artifact_type,provider,model,prompt_version,input_sha256,answer,created_at FROM ai_artifacts WHERE paper_id=? ORDER BY created_at DESC LIMIT 5", (paper["id"],))]
        return self.send_json(rows)

    def do_POST(self):
        path = urlparse(self.path).path
        try:
            if path == "/api/settings/model/test":
                try:
                    return self.send_json(test_model_connection())
                except (HTTPError, URLError, TimeoutError, OSError, ValueError) as exc:
                    return self.send_json({"error": f"模型连接测试失败：{str(exc)[:500]}"}, 502)
            if path == "/api/papers":
                data = self.read_json()
                pid, created = upsert_paper(data, source="manual")
                return self.send_json({"id": pid, "created": created}, 201 if created else 200)
            if path == "/api/discover":
                data = self.read_json()
                result = run_query(data.get("query", ""), data.get("sources", ["arxiv"]), data.get("limit", 20), name=data.get("name", ""), options=data.get("options", {}))
                return self.send_json(result)
            if path == "/api/discover/plan":
                data = self.read_json()
                query = clean_text(data.get("query", ""), 1000)
                sources = [s for s in data.get("sources", ["arxiv"]) if s in SOURCE_NAMES and s in SOURCE_SEARCH]
                if not query or not sources:
                    raise ValueError("需要检索词和至少一个有效来源")
                return self.send_json(search_query_plan(query, sources, data.get("options", {})))
            if path == "/api/discover/agent-plan":
                data = self.read_json()
                query = clean_text(data.get("query", ""), 1000)
                sources = [s for s in data.get("sources", ["arxiv"]) if s in SOURCE_NAMES and s in SOURCE_SEARCH]
                if not query or not sources:
                    raise ValueError("需要检索词和至少一个有效来源")
                try:
                    return self.send_json(agent_discovery_plan(query, sources, data.get("options", {})))
                except (HTTPError, URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
                    return self.send_json({"error": f"模型检索规划失败：{str(exc)[:500]}"}, 502)
            if path.startswith("/api/papers/") and path.endswith("/extract"):
                return self.send_json(extract_paper_documents(path.split("/")[3]))
            if path.startswith("/api/papers/") and path.endswith("/expand"):
                data = self.read_json()
                return self.send_json(expand_openalex_relations(path.split("/")[3], data.get("limit", 24)))
            if path.startswith("/api/papers/") and path.endswith("/feedback"):
                paper_id = path.split("/")[3]
                data = self.read_json()
                decision = data.get("decision")
                if decision not in RECOMMENDATION_DECISIONS:
                    raise ValueError("反馈必须是 relevant、irrelevant 或 later")
                scope = clean_text(data.get("scope", "global"), 120) or "global"
                note = clean_text(data.get("note", ""), 500)
                with DB_LOCK, db_session() as db:
                    if not db.execute("SELECT 1 FROM papers WHERE id=?", (paper_id,)).fetchone():
                        return self.send_json({"error": "论文不存在"}, 404)
                    db.execute("INSERT INTO learning_feedback(paper_id,scope,decision,note,created_at) VALUES(?,?,?,?,?) ON CONFLICT(paper_id,scope) DO UPDATE SET decision=excluded.decision,note=excluded.note,created_at=excluded.created_at", (paper_id, scope, decision, note, now_iso()))
                    record_audit(db, "feedback.updated", "paper", paper_id, {"scope": scope, "decision": decision})
                return self.send_json({"updated": True, "paper_id": paper_id, "scope": scope, "decision": decision})
            if path == "/api/queries":
                return self.save_query(self.read_json())
            if path.startswith("/api/queries/") and path.endswith("/run"):
                qid = path.split("/")[3]
                with DB_LOCK, db_session() as db:
                    row = db.execute("SELECT * FROM saved_queries WHERE id=?", (qid,)).fetchone()
                if not row:
                    return self.send_json({"error": "主题不存在"}, 404)
                try:
                    search_options = json.loads(row["search_options_json"] or "{}")
                except (json.JSONDecodeError, TypeError):
                    search_options = {}
                result = run_query(row["query"], json.loads(row["sources_json"]), 25, qid, False, row["name"], search_options)
                return self.send_json(result)
            if path == "/api/import":
                return self.import_data(self.read_json())
            if path.startswith("/api/papers/") and path.endswith("/attachment"):
                return self.add_attachment(path.split("/")[3], self.read_json())
            if path.startswith("/api/papers/") and path.endswith("/agent-brief"):
                return self.agent_brief(path.split("/")[3], self.read_json())
            if path.startswith("/api/papers/") and path.endswith("/references/sync"):
                try:
                    return self.send_json(sync_openalex_references(path.split("/")[3]))
                except (HTTPError, URLError, TimeoutError, OSError) as exc:
                    return self.send_json({"error": f"OpenAlex 引用同步失败：{str(exc)[:400]}"}, 502)
            if path == "/api/backup":
                return self.create_backup()
            if path == "/api/backup/restore":
                return self.restore_backup(self.read_json())
            return self.send_error(404)
        except ValueError as exc:
            return self.send_json({"error": str(exc)}, 400)
        except Exception as exc:
            return self.send_json({"error": f"操作失败：{str(exc)[:700]}"}, 500)

    def do_PATCH(self):
        path = urlparse(self.path).path
        try:
            if path == "/api/settings/model":
                return self.send_json(save_model_settings(self.read_json()))
            if path.startswith("/api/papers/"):
                pid = path.split("/")[3]
                data = self.read_json()
                allowed = {"status", "topic", "tags", "notes", "is_favorite"}
                updates = {k: v for k, v in data.items() if k in allowed}
                if "status" in updates and updates["status"] not in PAPER_STATUSES:
                    raise ValueError("未知阅读状态")
                if not updates:
                    raise ValueError("没有可更新的字段")
                assignments, values = [], []
                for key, value in updates.items():
                    if key == "tags":
                        key, value = "tags_json", json.dumps(value if isinstance(value, list) else [x.strip() for x in str(value).split(",") if x.strip()], ensure_ascii=False)
                    if key == "is_favorite":
                        value = int(bool(value))
                    assignments.append(f"{key}=?")
                    values.append(value)
                with DB_LOCK, db_session() as db:
                    cur = db.execute(f"UPDATE papers SET {','.join(assignments)},updated_at=? WHERE id=?", (*values, now_iso(), pid))
                    if cur.rowcount:
                        record_audit(db, "paper.updated", "paper", pid, {"fields": sorted(updates)})
                return self.send_json({"updated": cur.rowcount > 0})
            if path.startswith("/api/queries/") and "/matches/" in path:
                parts = path.split("/")
                query_id, paper_id = parts[3], parts[5]
                data = self.read_json()
                decision = data.get("user_decision")
                if decision not in QUERY_DECISIONS:
                    raise ValueError("未知的主题判断")
                viewed_at = now_iso() if data.get("viewed", True) else ""
                with DB_LOCK, db_session() as db:
                    cur = db.execute("UPDATE query_matches SET user_decision=?,viewed_at=? WHERE query_id=? AND paper_id=?", (decision, viewed_at, query_id, paper_id))
                if not cur.rowcount:
                    return self.send_json({"error": "主题匹配记录不存在"}, 404)
                with DB_LOCK, db_session() as db:
                    record_audit(db, "query_match.feedback", "query_match", f"{query_id}:{paper_id}", {"decision": decision, "viewed": bool(data.get("viewed", True))})
                return self.send_json({"updated": True, "user_decision": decision, "viewed_at": viewed_at})
            if path.startswith("/api/queries/"):
                qid = path.split("/")[3]
                data = self.read_json()
                allowed = {"name", "query", "sources", "search_options", "cadence_hours", "active"}
                updates = {k: v for k, v in data.items() if k in allowed}
                if not updates:
                    raise ValueError("没有可更新的字段")
                assignments, values = [], []
                for key, value in updates.items():
                    if key == "sources":
                        key, value = "sources_json", json.dumps([s for s in value if s in SOURCE_NAMES and s in SOURCE_SEARCH])
                    if key == "search_options":
                        key, value = "search_options_json", json.dumps(normalize_search_options(value if isinstance(value, dict) else {}), ensure_ascii=False)
                    if key == "cadence_hours":
                        value = min(max(int(value), 24), 8760)
                    if key == "active":
                        value = int(bool(value))
                    assignments.append(f"{key}=?")
                    values.append(value)
                with DB_LOCK, db_session() as db:
                    db.execute(f"UPDATE saved_queries SET {','.join(assignments)},updated_at=? WHERE id=?", (*values, now_iso(), qid))
                return self.send_json({"updated": True})
        except ValueError as exc:
            return self.send_json({"error": str(exc)}, 400)
        return self.send_error(404)

    def do_DELETE(self):
        path = urlparse(self.path).path
        if path.startswith("/api/queries/"):
            qid = path.split("/")[3]
            # Soft stop, preserving run history and query identity.
            with DB_LOCK, db_session() as db:
                db.execute("UPDATE saved_queries SET active=0,updated_at=? WHERE id=?", (now_iso(), qid))
                record_audit(db, "query.disabled", "saved_query", qid, {})
            return self.send_json({"stopped": True})
        return self.send_error(404)

    def save_query(self, data):
        name = clean_text(data.get("name"), 200) or clean_text(data.get("query"), 200)
        query = clean_text(data.get("query"), 1000)
        sources = [s for s in data.get("sources", ["arxiv"]) if s in SOURCE_NAMES and s in SOURCE_SEARCH]
        search_options = normalize_search_options(data.get("search_options", {}))
        cadence = min(max(int(data.get("cadence_hours", 168)), 24), 8760)
        if not query or not sources:
            raise ValueError("请填写检索词并至少选择一个来源")
        qid = str(uuid.uuid4())
        now = datetime.now(timezone.utc).replace(microsecond=0)
        with DB_LOCK, db_session() as db:
            db.execute("INSERT INTO saved_queries(id,name,query,sources_json,search_options_json,cadence_hours,active,last_run_at,next_run_at,created_at,updated_at) VALUES(?,?,?,?,?, ?,1,'',?,?,?)", (qid, name, query, json.dumps(sources), json.dumps(search_options, ensure_ascii=False), cadence, now.isoformat(), now.isoformat(), now.isoformat()))
            record_audit(db, "query.created", "saved_query", qid, {"sources": sources, "search_options": search_options, "cadence_hours": cadence})
        return self.send_json({"id": qid, "name": name, "query": query, "sources": sources, "search_options": search_options, "cadence_hours": cadence, "active": True, "next_run_at": now.isoformat()}, 201)

    def import_data(self, data):
        fmt = data.get("format", "json")
        content = clean_text(data.get("content"), 25_000_000)
        records = []
        if fmt == "json":
            obj = json.loads(content)
            records = obj.get("papers", obj) if isinstance(obj, dict) else obj
        elif fmt == "bibtex":
            chunks = re.split(r"(?=\s*@\w+\s*\{)", content)
            for chunk in chunks:
                if not chunk.strip().startswith("@"):
                    continue
                entry = re.search(r"@\w+\s*\{\s*([^,]+),", chunk)
                fields = {m.group(1).lower(): re.sub(r"\\[{}]", "", m.group(2)).strip() for m in re.finditer(r"(\w+)\s*=\s*[\{\"](.*?)[\}\"]\s*,?\s*(?=\w+\s*=|\})", chunk, re.S)}
                if fields.get("title"):
                    records.append({"title": fields.get("title"), "authors": fields.get("author", ""), "year": fields.get("year"), "doi": fields.get("doi", ""), "abstract": fields.get("abstract", ""), "venue": fields.get("journal", fields.get("booktitle", "")), "url": fields.get("url", "")})
        elif fmt == "ris":
            for chunk in re.split(r"(?=^TY  - )", content, flags=re.M):
                if not chunk.strip():
                    continue
                fields = {}
                authors = []
                for line in chunk.splitlines():
                    m = re.match(r"([A-Z0-9]{2})  - (.*)", line)
                    if not m:
                        continue
                    key, val = m.groups()
                    if key in {"AU", "A1"}:
                        authors.append(val)
                    else:
                        fields.setdefault(key, val)
                if fields.get("TI") or fields.get("T1"):
                    records.append({"title": fields.get("TI", fields.get("T1")), "authors": ", ".join(authors), "year": fields.get("PY", "")[:4], "doi": fields.get("DO", ""), "abstract": fields.get("AB", ""), "venue": fields.get("JO", fields.get("T2", "")), "url": fields.get("UR", "")})
        else:
            raise ValueError("当前支持 JSON、BibTeX 和 RIS 导入")
        if not isinstance(records, list):
            raise ValueError("导入数据格式无效")
        created = duplicates = errors = 0
        for record in records[:10000]:
            try:
                _, is_new = upsert_paper(record, source="import", external_id=record.get("doi", ""), raw={"import_format": fmt})
                created += int(is_new)
                duplicates += int(not is_new)
            except Exception:
                errors += 1
        with DB_LOCK, db_session() as db:
            record_audit(db, "library.imported", "import", "", {"format": fmt, "records": min(len(records), 10000), "imported": created, "duplicates": duplicates, "errors": errors})
        return self.send_json({"imported": created, "duplicates": duplicates, "errors": errors})

    def export_json(self):
        with DB_LOCK, db_session() as db:
            papers = [paper_dict(r) for r in db.execute("SELECT * FROM papers ORDER BY created_at")]
            sources = [dict(r) for r in db.execute("SELECT * FROM source_records ORDER BY id")]
            queries = [dict(r) for r in db.execute("SELECT * FROM saved_queries ORDER BY created_at")]
            for query in queries:
                try:
                    query["sources"] = json.loads(query.pop("sources_json", "[]") or "[]")
                except json.JSONDecodeError:
                    query["sources"] = []
                try:
                    query["search_options"] = json.loads(query.pop("search_options_json", "{}") or "{}")
                except json.JSONDecodeError:
                    query["search_options"] = {}
            runs = [dict(r) for r in db.execute("SELECT * FROM runs ORDER BY started_at")]
            attachments = [dict(r) for r in db.execute("SELECT * FROM attachments")]
            matches = [dict(r) for r in db.execute("SELECT * FROM query_matches ORDER BY last_seen_at")]
            citations = [dict(r) for r in db.execute("SELECT * FROM citation_edges ORDER BY id")]
            feedback = [dict(r) for r in db.execute("SELECT * FROM learning_feedback ORDER BY created_at")]
            audit = [dict(r) for r in db.execute("SELECT * FROM audit_events ORDER BY id")]
            artifacts = [dict(r) for r in db.execute("SELECT * FROM ai_artifacts ORDER BY created_at")]
            model = dict(db.execute("SELECT provider,base_url,model,temperature,enabled,updated_at FROM model_config WHERE id=1").fetchone() or {})
            document_pages = [dict(r) for r in db.execute("SELECT * FROM document_pages ORDER BY paper_id,attachment_id,page_number")]
        payload = {"schema_version": DB_SCHEMA_VERSION, "exported_at": now_iso(), "papers": papers, "source_records": sources, "saved_queries": queries, "runs": runs, "query_matches": matches, "citation_edges": citations, "learning_feedback": feedback, "audit_events": audit, "ai_artifacts": artifacts, "model_config": model, "attachments": attachments, "document_pages": document_pages}
        return self.send_download("literature-library.json", "application/json; charset=utf-8", json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8"))

    def export_bibtex(self):
        with DB_LOCK, db_session() as db:
            papers = [paper_dict(r) for r in db.execute("SELECT * FROM papers ORDER BY year DESC,title")]
        lines = []
        for p in papers:
            key = re.sub(r"\W+", "", ((p.get("authors", "").split(",")[0].split()[-1:] or ["paper"])[0] + str(p.get("year") or "") + p["id"][:4]))
            fields = [("title", p["title"]), ("author", p["authors"]), ("year", p["year"]), ("journal", p["venue"]), ("doi", p["doi"]), ("url", p["url"]), ("abstract", p["abstract"])]
            lines.append("@article{" + key + ",")
            for k, v in fields:
                if v:
                    lines.append(f"  {k} = {{{str(v).replace('{','(').replace('}',')')}}},")
            lines.append("}\n")
        return self.send_download("literature-library.bib", "application/x-bibtex; charset=utf-8", "\n".join(lines).encode("utf-8"))

    def send_download(self, filename: str, content_type: str, data: bytes):
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Content-Length", str(len(data)))
        self.send_header("X-Request-ID", getattr(self, "request_id", ""))
        self.end_headers()
        self.wfile.write(data)

    def add_attachment(self, paper_id: str, data: dict):
        filename = Path(clean_text(data.get("filename"), 250)).name
        if not filename.lower().endswith(".pdf"):
            raise ValueError("当前仅支持 PDF 附件")
        try:
            content = __import__("base64").b64decode(data.get("data", ""), validate=True)
        except Exception:
            raise ValueError("PDF 文件数据无法读取")
        if len(content) > 100 * 1024 * 1024:
            raise ValueError("单个 PDF 限制为 100 MB")
        if not content.startswith(b"%PDF"):
            raise ValueError("文件内容不像有效 PDF")
        with DB_LOCK, db_session() as db:
            if not db.execute("SELECT 1 FROM papers WHERE id=?", (paper_id,)).fetchone():
                return self.send_json({"error": "论文不存在"}, 404)
        digest = hashlib.sha256(content).hexdigest()
        FILES_DIR.mkdir(parents=True, exist_ok=True)
        stored = digest + ".pdf"
        target = FILES_DIR / stored
        if not target.exists():
            target.write_bytes(content)
        aid = str(uuid.uuid4())
        with DB_LOCK, db_session() as db:
            db.execute("INSERT INTO attachments(id,paper_id,original_name,stored_name,sha256,byte_size,added_at) VALUES(?,?,?,?,?,?,?)", (aid, paper_id, filename, stored, digest, len(content), now_iso()))
            record_audit(db, "attachment.added", "paper", paper_id, {"sha256": digest, "byte_size": len(content)})
        return self.send_json({"id": aid, "filename": filename, "sha256": digest, "url": "/files/" + stored}, 201)

    def create_backup(self):
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        destination = BACKUP_DIR / f"researchdesk-backup-{stamp}.zip"
        with DB_LOCK:
            # SQLite's backup API creates a consistent copy even when WAL is active.
            live = connect()
            copy_path = BACKUP_DIR / f"snapshot-{stamp}.sqlite3"
            target = sqlite3.connect(copy_path)
            live.backup(target)
            target.close()
            live.close()
        files = []
        for file in sorted(FILES_DIR.glob("*.pdf")) if FILES_DIR.exists() else []:
            files.append({"path": "files/" + file.name, "sha256": hashlib.sha256(file.read_bytes()).hexdigest(), "bytes": file.stat().st_size})
        manifest = {"product": "研究生论文工作台", "app_version": APP_VERSION, "schema_version": DB_SCHEMA_VERSION, "created_at": now_iso(), "database": {"path": "literature.sqlite3", "sha256": hashlib.sha256(copy_path.read_bytes()).hexdigest()}, "files": files}
        with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(copy_path, "literature.sqlite3")
            if FILES_DIR.exists():
                for file in FILES_DIR.glob("*.pdf"):
                    zf.write(file, "files/" + file.name)
            zf.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
        copy_path.unlink(missing_ok=True)
        with DB_LOCK, db_session() as db:
            record_audit(db, "backup.created", "backup", destination.name, {"attachment_count": len(files), "sha256": manifest["database"]["sha256"]})
        return self.send_json({"path": str(destination), "filename": destination.name, "download_url": "/api/backups/" + destination.name, "papers": manifest["database"]["sha256"], "attachment_count": len(files), "manifest": manifest})

    def restore_backup(self, data):
        filename = clean_text(data.get("filename"), 250)
        if Path(filename).name != filename or not filename.lower().endswith(".zip"):
            raise ValueError("备份文件名无效")
        content = __import__("base64").b64decode(data.get("data", ""), validate=True)
        if len(content) > 2 * 1024 * 1024 * 1024:
            raise ValueError("备份包超过 2 GB 限制")
        temp = BACKUP_DIR / ("restore-" + str(uuid.uuid4()) + ".zip")
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        temp.write_bytes(content)
        try:
            with zipfile.ZipFile(temp, "r") as zf:
                names = zf.namelist()
                if "manifest.json" not in names or "literature.sqlite3" not in names:
                    raise ValueError("备份缺少 manifest 或数据库")
                manifest = json.loads(zf.read("manifest.json"))
                db_bytes = zf.read("literature.sqlite3")
                if hashlib.sha256(db_bytes).hexdigest() != manifest.get("database", {}).get("sha256"):
                    raise ValueError("数据库校验失败，未恢复")
                # Reject paths that could escape the selected data directories.
                for name in names:
                    p = Path(name)
                    if p.is_absolute() or ".." in p.parts:
                        raise ValueError("备份包含非法路径")
                staged_db = BACKUP_DIR / ("staged-" + str(uuid.uuid4()) + ".sqlite3")
                staged_db.write_bytes(db_bytes)
                check = sqlite3.connect(staged_db)
                integrity = check.execute("PRAGMA integrity_check").fetchone()[0]
                check.close()
                if integrity != "ok":
                    staged_db.unlink(missing_ok=True)
                    raise ValueError("SQLite 完整性检查失败")
                staged_files = []
                for info in manifest.get("files", []):
                    rel = info.get("path", "")
                    if rel not in names or not rel.startswith("files/"):
                        continue
                    payload = zf.read(rel)
                    if hashlib.sha256(payload).hexdigest() != info.get("sha256"):
                        staged_db.unlink(missing_ok=True)
                        raise ValueError(f"附件校验失败：{rel}")
                    staged_files.append((Path(rel).name, payload))
                with DB_LOCK:
                    if DB_PATH.exists():
                        safety = BACKUP_DIR / f"before-restore-{datetime.now().strftime('%Y%m%d-%H%M%S')}.sqlite3"
                        live = connect()
                        safe = sqlite3.connect(safety)
                        live.backup(safe)
                        safe.close()
                        live.close()
                    os.replace(staged_db, DB_PATH)
                    FILES_DIR.mkdir(parents=True, exist_ok=True)
                    for name, payload in staged_files:
                        (FILES_DIR / name).write_bytes(payload)
                    # Backups from older releases may predate new local
                    # memory tables; rerun the idempotent schema initializer
                    # after swapping the verified database into place.
                    init_db()
                    with db_session() as db:
                        record_audit(db, "backup.restored", "backup", filename, {"attachments_restored": len(staged_files), "source_schema_version": manifest.get("schema_version")})
                return self.send_json({"restored": True, "papers_checked": manifest.get("database", {}).get("sha256"), "attachments_restored": len(staged_files), "safety_copy_created": True})
        finally:
            temp.unlink(missing_ok=True)

    def agent_brief(self, paper_id: str, data: dict):
        if not data.get("consent"):
            raise ValueError("请先确认允许将这篇论文的元数据/摘要发送到已配置的模型服务")
        settings = model_settings()
        api_key = RUNTIME_MODEL_KEY or os.environ.get("LIT_AGENT_API_KEY", "")
        if not api_key or not settings["enabled"]:
            return self.send_json({"error": "尚未启用模型服务。请在页面的模型配置中填写 OpenAI 兼容 API Key 并启用，或设置 LIT_AGENT_API_KEY。"}, 503)
        base = settings["base_url"]
        model = settings["model"]
        with DB_LOCK, db_session() as db:
            row = db.execute("SELECT * FROM papers WHERE id=?", (paper_id,)).fetchone()
        if not row:
            return self.send_json({"error": "论文不存在"}, 404)
        prompt_version = "abstract-brief-v1"
        prompt = "你是严谨的研究生论文助读助手。仅根据提供的题名、摘要和元数据，用中文输出：研究问题、方法线索、可能贡献、需要核验的问题、适合继续阅读的段落/实验。摘要不足以支持的内容写‘摘要无法确认’，禁止编造页码、实验数值或原文引文。明确这只是基于摘要的初筛。"
        user = json.dumps({"title": row["title"], "authors": row["authors"], "year": row["year"], "venue": row["venue"], "abstract": row["abstract"]}, ensure_ascii=False)
        body = json.dumps({"model": model, "messages": [{"role": "system", "content": prompt}, {"role": "user", "content": user}], "temperature": settings["temperature"]}).encode("utf-8")
        req = Request(base + "/chat/completions", data=body, headers={"Authorization": "Bearer " + api_key, "Content-Type": "application/json", "User-Agent": USER_AGENT}, method="POST")
        try:
            with urlopen(req, timeout=90) as resp:
                result = json.loads(resp.read().decode("utf-8"))
            answer = result["choices"][0]["message"]["content"]
        except Exception as exc:
            return self.send_json({"error": f"模型服务请求失败：{str(exc)[:400]}"}, 502)
        created = now_iso()
        input_hash = hashlib.sha256(user.encode("utf-8")).hexdigest()
        with DB_LOCK, db_session() as db:
            db.execute("INSERT INTO ai_artifacts(id,paper_id,artifact_type,provider,model,prompt_version,input_sha256,answer,created_at) VALUES(?,?,?,?,?,?,?,?,?)", (str(uuid.uuid4()), paper_id, "abstract_brief", base, model, prompt_version, input_hash, answer, created))
        return self.send_json({"model": model, "answer": answer, "basis": "标题、摘要和元数据；非全文证据", "created_at": created, "prompt_version": prompt_version, "input_sha256": input_hash})


def main():
    global SCHEDULER_STARTED_AT
    init_db()
    FILES_DIR.mkdir(parents=True, exist_ok=True)
    SCHEDULER_STARTED_AT = now_iso()
    thread = threading.Thread(target=scheduler_loop, name="paper-query-scheduler", daemon=True)
    thread.start()
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"研究生论文工作台已启动：http://{HOST}:{PORT}")
    print(f"本地数据目录：{DATA_DIR}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        STOP_EVENT.set()
        server.server_close()


if __name__ == "__main__":
    main()
